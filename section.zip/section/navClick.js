function clickNav (section) {
    alert(section+" click! ");
}