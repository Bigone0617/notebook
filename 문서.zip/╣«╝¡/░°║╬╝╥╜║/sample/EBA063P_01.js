﻿ecount.page.factory("ecount.page", "ESD006M", {
    /********************************************************************** 
    *   Init Data Setting function
    **********************************************************************/
    //page init event
    init: function (options) {
        this._super.init.apply(this, arguments);
    },

    //page render event
    render: function () {
        this._super.render.apply(this);
    } ,
   
//header
    onInitHeader: function(header){
        var g = widget.generator,
        contents = g.contents(),
        control = g.control();
        var btn = control.define("widget.button","search","btn1")
                        .label("Search");

        header.setTitle("NewCount");
        header.add(btn);
    },

//contents
    onInitContents: function(contents){
        var g = widget.generator,
        form = g.form()
        control = g.control()
        grid1= g.grid();
        
        var rowData = [];

        grid1.setColumns([
            {
                id: "prod_cd",
                title : "품목코드",
                width : 100 ,
                controlType:'widget.code.prod',
            },
            {
                id: "prod_des",
                title : "품목명",
                width : 100,
                controlType:'widget.input.general',
                fontBold: 1
            },
            {
                id: "qty",
                title : "수량",
                width : 100,
                controlType:'widget.input.number',
                align : "center",
                controlOption : {
                    decimalUnit : [18,6],
                },
                dataType:'96' //화면에 보이는 값만 변경, 데이터는 변경 안함
            },
            {
                id: "price",
                title : "단가",
                width : 100,
                controlType:'widget.input.number',
                align : "center",
                //linechange : true
            },
            {
                id: "supply_amt",
                title : "공급가액",
                width : 100,
                controlType:'widget.input.number',
                align : "center"
            },
            {
                id: "vat_amt",
                title : "부가세",
                width : 100,
                controlType:'widget.input.number',
                align : "center"
            },
            {
                id: "inspection",
                title : "검사",
                width : 100,
                controlType:'widget.select'
            },
            {
                id: "size_des",
                title : "규격선택",
                width : 80,
                controlType:'widget.input.general',
                isHideColumn : true //true이면 안보임
            }
        ])
        .setRowData([])
        .setEditable(true,3,5)
        .setCheckBoxUse(true)
        .setEventAutoAddRowOnLastRow(true,2)
        .setColumnsAutoSetting({
            'qty' : {'actionType' : 'sum','total':0},
            'price' : {'actionType' : 'sum','total':0},
            'supply_amt' : {'actionType' : 'sum','total':0},
            'vat_amt' : {'actionType' : 'sum','total':0},
        })
        .setEditSpecialRowCount(1)
        .setEditRowMoveable(true)
        .setCustomRowCell('inspection',this.inspectionSetting.bind(this))
        .setCustomRowCell('qty',this.qtyCoppy.bind(this))
        .setCustomRowCell('supply_amt',this.supplySetting.bind(this))

        contents.addGrid("grid1",grid1);
    },

   
//footer
    onInitFooter: function(footer){
        var g = widget.generator,
        control = g.control(),
        toolbar = g.toolbar();
        toolbar.addLeft(control.define("widget.button","save","save")
                               .label("save")
                               .end())
                .addLeft(control.define("widget.button","up","up")
                               .label("up")
                               .end())
                .addLeft(control.define("widget.button","down","down")
                               .label("down")
                               .end())
                .end();
        footer.add(toolbar);


    },

//function
    onFooterSave : function(){
        this.console("hi!!!");
    },
    onFooterUp : function(){
        var grid = this.contents.getGrid('grid1').grid;
        grid.moveUpChecked();
    },
    onFooterDown : function(){
        var grid = this.contents.getGrid('grid1').grid;
        grid.moveDownChecked();
    },
    inspectionSetting : function(){
        var option = {};
        var selectOption = [];
        selectOption.push(["0","선택"]);
        selectOption.push(["1","숨기기"]);
        selectOption.push(["2","보이기"]);

        option.optionData = selectOption;

        option.event = {
            'change' : function(e,data){
                var grid = this.contents.getGrid('grid1').grid;
                if(data.newValue === "1"){
                    grid.setColumnVisibility('size_des',false);
                }else if (data.newValue === "2"){
                    grid.setColumnVisibility('size_des',true);
                }
            }.bind(this)
        }

        return option;
    },
    qtyCoppy : function(){
        var grid = this.contents.getGrid('grid1').grid;
        var option = {};
        option.event = {
            'focus' : function(e, data){
                var key = data.rowKey;
                var nowIndex = grid.getRowIndexByKey(key);
                if(nowIndex != 0){
                    var beforeRowKey = grid.getRowKeyByIndex(nowIndex-1);
                    var beforeValue = grid.getCell('qty',beforeRowKey);
                    if(beforeValue !== ""){
                        grid.setCell('qty',nowIndex,beforeValue);
                        grid.addChecked(key);
                    }
                }
            }.bind(this)
        }
        return option;
    },
    supplySetting : function(){
        var grid = this.contents.getGrid('grid1').grid;
        var option = {};

        option.event = {
            'change' : function(e, data){
                var amtValue = data.newValue * 0.1;
                var rowKey = data.rowKey;
                this.console(data.newValue);
                grid.setCell("vat_amt",rowKey,amtValue);
            }.bind(this)
        }

        return option;
    },
    console : function(obj){
        console.log("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
        console.log(obj);
        console.log("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
    }
});