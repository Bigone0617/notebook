﻿/****************************************************************************************************
1. Create Date : 2018-04-03
2. Creator     : 허휘영
3. Description : 판매입력(Sale)
4. Precaution  :                
5. History     : 2018.09.18 (TanThanh) - Change function Copy to footer Copy button
                 2019.01.09 (HoangLinh): A18_04370_1 - Refactoring
                 2019.01.29 (PhiVo) A19_00340 - FE 리팩토링_페이지 일괄작업 5차 - apply method getFnItemById and not use method getFnItem in method save
                 2019.06.10 (AiTuan) - A18_01169 - 참조 공통화(판매입력)
                 2019.07.18 (AiTuan) - Set refTabId = this.tabIdList.main
                 2019.08.26 (허휘영) - 입력공통 리팩토링 단위 기능분리
                 2019.09.17 [LuongAnhDuy] A19_02831 -  재고 > 확인 권한이 있어도 미확인 전표수정시 미확인상태로 유지
6. MenuPath    : 재고1>영업관리>판매>판매입력
7. Old File    : View.ESD/XESD006M.js 
9. Etc         :  
****************************************************************************************************/
ecount.page.factory("ecount.page.common", "EBA068M", {
    /********************************************************************** 
    *   Init Data Setting function
    **********************************************************************/
    //page init event
    init: function (options) {
        
        this._super.init.apply(this, arguments);
        this.__ecPageID = this.pageID+"_1";
    },

    //page render event
    render: function () {
        this._super.render.apply(this, arguments);
    } ,
    initProperties: function () {
        this.pageOption.columnMap = {
            grid: {
                IO_DATE: "IO_DATE", IO_NO: "IO_NO",
            },
        }
        
        this.pageInfo = {
            
           title:"TodoList",	// 타이틀
            

            pageHeader: [
                {
                    group: "header", id: "header",
                    child: [
                        {unit: "widget", type:"outputTitle"},
                        { unit: "widget", type: "quickSearch" },
                        {
                            group: "tabContents", type: "searchForm", id: "searchForm",
                            functions: ["userTab"],
                            settingInfo: {
                                isInitShowSearchTab: false,
                                isSerializeAllUse: false
                            },
                            child: [
                            ]
                        },
                    ]
                }
            ],
            pageContents: [
                {
                    group: "contents", id: "contents", type: "output",
                    functions: [
                        { function: "setOutputLayout" }
                    ],
                    child: [
                        //그리드
                        {
                            group: "grid", type: "form", id: "gridForm-ESD002M",
                            settingInfo: {
                                keyColumn: ["EST_DATE", "EST_NO"],
                                renderType: "columnFix",
                            },
                            child: [
                            ],
                            functions: [
                            ],
                        }
                    ]
                }
            ],
            pageFooter: [
                {
                    group: "footer", id: "footer",
                    child: [
                        {
                            group: "toolbar", id: "toolbarFooter", sortType: "output-common-footer",
                            functions: ["procNewSlip"],
                            child: [
                                {
                                    unit: "widget", type: "new"
                                },
                                // {
                                //     unit: "widget", type: "outputSave"
                                // },
                                // {
                                //     unit: "widget", type: "outputDelete"
                                // },
                               
                            ]
                        }
                    ]
                }
            ],
            pageFunction: [
                { function: "reloadPage" },
                { function: "outputFormManager" },
                {
                    function: "searchManager",
                    settingInfo: {
                        isFirstLoadSearch: true,
                        defaultSearchParam: {
                            
                        }
                    }
                },
            ]
        }

    },
    onInitUnitWidgetNew: function(){
        var customOption = {
            isOverriding: true,
             //init
             init: function (option) {
                eccomposite_v1.unit.widget.prototype.init.apply(this, arguments);
            },

            //render
            render: function (parent) {
                eccomposite_v1.unit.widget.prototype.render.apply(this, arguments);

                //인스턴스 추가
                this.createLayout(parent);
            },

            creataLayout: function(parent){
                var g = widget.generator,
                 control = g.control();

                 control.define("widget.button","new").label("신규");
                 parent.addLeft(contorl);
                }
            
        }
        return customOption;
    },
});
