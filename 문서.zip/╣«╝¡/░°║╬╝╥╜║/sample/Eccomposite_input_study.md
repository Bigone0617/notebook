1. 그리드 양식설정 옵션중 [이전줄 값 복사] 기능은 어떤 로직으로 동작 하는가?
eccomposite_v1.group.grid.js

  //기본값 설정이 [이전줄 복사]로 설정되 있는 경우
            if (column && column.inputValue && column.inputValue.Defaults && column.inputValue.Defaults.where(function (x) { return x.DEFAULT_TYPE == "BEFORE" }).length > 0) {
                focusEventList.push(function (column, gridId, e, data) {
                    //기본값설정시 같이 설정해야할 셀이 있는 컬럼목록
                    var copyWithColumns = this.getFormDefaultValueWithCellList();

                    //이전줄복사 목록이 있는지 조회
                    var list = this.formDefaultValue.getRelateTypeBottom("BEFORE", [column], {
                        grid: this.getGrid(gridId),
                        rowKey: data.rowItem[ecount.grid.constValue.keyColumnPropertyName],
                        copyWithColumns: copyWithColumns,
                        type: "prod-focus",
                        onlyTypeList: ["BEFORE"]
                    });

                    //이전줄 복사가 하나라도 있으면 focus 이벤트에 이벤트 추가
                    if (list.length > 0) {
                        //기본값 설정
                        for (var i = 0; i < list.length; i++) {
                            this.getGrid(gridId).setCell(list[i].id, data.rowItem[ecount.grid.constValue.keyColumnPropertyName], list[i].Value);
                        }

                        return true;
                    }

                    return false;
                }.bind(this));
            }

2. 그리드 항목중 품목에 값을 입력하는 방법은?
eccomposite_v1.unit.gridCell.prod_cd.js
 //ItemClick event handler(품목 정보 보기)
    onDropdownItemClick: function (rowKey, arg) {
        switch (arg.originId) {
            case "prodcdInformation"://품목중심입력 팝업오픈
                this.fnOpenProdFocusedInput(rowKey, arg);
                break;
            case "favoriteCodeTreeSetup"://자주사용하는코드 팝업오픈
                arg.control.dropdownLayerClick(arg);
                break;
        }
    },
    
    //ItemSelect event handler
    onCodeItemSelect: function (rowKey, arg) {
        //닫기를 누른경우 진행하지 않고 종료
        if (arg.message && arg.message.data && arg.message.data.closeFlag) {
            return false;
        }        

        this.fnGetProdInput(rowKey, arg);
    }, 

    //auto complete handler
    onAutoCompleteHandler: function (control, keyword, parameter, handler) {
        //창고 
        var wh_cd = { value: "", label: "" };
        if (this.getComposite("wh_cd")) {
            wh_cd = this.getComposite("wh_cd").getSelectedValue(control.rowKey);
        } else if (this.getComposite("wh_des")) {
            wh_cd = this.getComposite("wh_des").getSelectedValue(control.rowKey);
        }

        //거래처
        var cust_cd = { value: "", label: "" };
        if (this.getComposite("cust")) {
            cust_cd = this.getComposite("cust").getSelectedValue(control.rowKey);
        } else if (this.getComposite("cust_des")) {
            cust_cd = this.getComposite("cust_des").getSelectedValue(control.rowKey);
        }
        
        parameter.FORM_SEQ = this.pageInfo.MYPROD_FORM_SEQ || "3";
        parameter.IO_TYPE = this.getProdCdIoType() || this.pageInfo.IO_TYPE;

        parameter.WH_CD = wh_cd.value || "";
        parameter.CUST = cust_cd.value || "";
        //검색 타입(버튼, 헤더) : B, H
        parameter.SeachType = "B";
        //신규등록여부
        parameter.NEWITEM = "";
        //검색조건(1: 상세검색, 2: 간편검색)
        parameter.SEARCH_GB = "0";
        parameter.SERIAL_DATE = this.pageOption.serialTime;
        parameter.BARCODE_SEARCH = this.getComposite("barcode", this.pageInfo.mainGridId) && this.getComposite("barcode", this.pageInfo.mainGridId).getUseBarcodeValue().count == 0 ? "N" : "Y";
        parameter.BARCODE2 = "N";

        //widget factory에서 설정하는 정보들
        parameter.PRICE_GROUP_FLAG = ecount.config.inventory.PRICE_GROUP_FLAG;
        parameter.SERIAL_FLAG = ecount.config.inventory.USE_SERIAL;
        parameter.OUT_VAT_RATE_YN = ecount.config.inventory.USE_OUT_VAT_RATE ? "Y" : "N";
        parameter.OUT_VAT_RATE = ecount.config.inventory.OUT_VAT_RATE;
        parameter.IN_VAT_RATE_YN = ecount.config.inventory.USE_IN_VAT_RATE ? "Y" : "N";
        parameter.IN_VAT_RATE = ecount.config.inventory.IN_VAT_RATE;        
        parameter.LAST_SELL_FUTURE_YN = ecount.config.inventory.USE_LAST_SELL_FUTURE ? "Y" : "N";
        parameter.SERIAL_WH_FLAG = ecount.config.inventory.USE_SERIAL_WH ? "Y" : "N";
        parameter.INI_COM_CODE = ecount.company.INNER_GYESET_CD;
        parameter.ALL_GROUP_PROD = ecount.user.ALL_GROUP_PROD;
        parameter.ALL_GROUP_WH = ecount.user.ALL_GROUP_WH;

        parameter.PARAM = keyword;
        handler(parameter);
        return true;
    },

    //init popup handler
    onPreInitPopupHandler: function (control, keyword, config, response) {
        if (response && response.length == 1 && !$.isEmpty(response[0].SIZE_CD)) {
            config.isOnePopupClose = false;
            control._allowOpenPopupOnSingleData = true;
        }

        this.getGrid().setCell(this.columnMap.price_discount_stand.id, control.rowKey, "0");
        this.getGrid().setCell(this.columnMap.price_vat_discount_stand.id, control.rowKey, "0");
    },

    //popup handleropenPopup
    onPopupHandler: function (control, config, handler) {
        //팝업 오픈 전 마지막 포커스 위치 저장
        this.setGridProdPopupOpenRowKey();

        $.extend(config, this.getGridProdPopupInfo(control.rowKey, null, config));

        if (config.eventTarget) {
            switch (config.eventTarget.toUpperCase()) {
                case "CHANGE":                   
                    this.setGridProdInfoDefault(control.rowKey, $.isEmpty(config.keyword));                                  
                    break;
                case "KEYDOWN":
                    config.SFLAG = "N";
                    config.url = "/ECERP/Popup.Search/ES018P";
                    config.keyword = config.__gridOpenPopupTriggerInfo.rowItem[this.columnMap.prod_cd.name];
                    config.width = 500;
                    config.height = 640;

                    break;
                case "DBLCLICK":
                    config.keyword = "";
                    break;
            }
        }

        //widget factory에서 설정하는 정보들
        //품목그룹 구분설정
        config.PRICE_GROUP_FLAG = ecount.config.inventory.PRICE_GROUP_FLAG;
        //시리얼 사용여부
        config.SERIAL_FLAG = ecount.config.inventory.USE_SERIAL;
        //매출 부가세율 사용여부
        config.OUT_VAT_RATE_YN = ecount.config.inventory.USE_OUT_VAT_RATE ? "Y" : "N";
        //매출 부가세율
        config.OUT_VAT_RATE = ecount.config.inventory.OUT_VAT_RATE;
        // 매입 직접입력 사용여부
        config.IN_VAT_RATE_YN = ecount.config.inventory.USE_IN_VAT_RATE ? "Y" : "N";
        // 매입 부가세율
        config.IN_VAT_RATE = ecount.config.inventory.IN_VAT_RATE;
        //판매최종단가 미래전표포함(30일)
        //**checkpooint 구매도 있으나 현재 오류가 있어 판매구분값만 사용하고 있음
        config.LAST_SELL_FUTURE_YN = ecount.config.inventory.USE_LAST_SELL_FUTURE ? "Y" : "N";
        //창고별 시리얼No.체크
        config.SERIAL_WH_FLAG = ecount.config.inventory.USE_SERIAL_WH ? "Y" : "N";
        //za코드
        config.INI_COM_CODE = ecount.company.INNER_GYESET_CD;
        //허용품목
        config.ALL_GROUP_PROD = ecount.user.ALL_GROUP_PROD;
        //허용부서
        config.ALL_GROUP_WH = ecount.user.ALL_GROUP_WH;

        handler(config);
    },

    //message handler(품목팝업)
    onMessageHandler_ES020P: function (event, data) {
        var firstData = data.data;
        
        var closeFlag = data.data.closeFlag || false;
        //닫힘 버튼 클릭 인 지확인
        if (closeFlag) {
            this.getGrid().restoreLastActiveCell();
            return;
        }

//생산품목입력
    setGoodSeachValue: function (grid, rowKey, rowData, rowIdx, isApi) {

        grid.setCellTransaction().start();

        grid.setCell(this.columnMap.good_cd.id, rowKey, rowData["PROD_CD"]);
        grid.setCell(this.columnMap.good_des.id, rowKey, rowData["PROD_DES"], { isRunChange: false });
        grid.setCell(this.columnMap.good_size_des.id, rowKey, rowData["SIZE_DES"]);

        if ((rowData.ItemCnt || 0) != 0) {
            return false;
        }

        grid.setCellTransaction().end();
        //포커스
        //적용 눌렀을 경우 처음 로드한 셀에 포커스            
        rowData["INPUTFOCUS"] = "prod_cd";
        if (rowData.ApplyGubun == true) {
            grid.setCellFocus(rowData["INPUTFOCUS"], rowData.oldrowKey);
        }
        else {
            if (!$.isEmpty(rowData["INPUTFOCUS"])) {
                grid.setCellFocus(rowData["INPUTFOCUS"], rowKey);
            }
        }

    },

3. 저장 버튼의 중복클릭 방지는 어떻게 동작 하는가?
ecount.page.common.js

mappingEventCallbackHandler

//파일 분리를 위해 이벤트 매핑작업해주는 function
    mappingEventCallbackHandler: function (event, subEvent, keys, shortCutKey) {
        if (arguments.length == 1 && typeof arguments[0] == "object") {
            subEvent = arguments[0].subEvent;
            keys = arguments[0].keys;
            shortCutKey = arguments[0].shortCutKey;

            event = arguments[0].event;
        }

        var eventList = [];//생성할 이벤트 function name
        var isPage = false;//_PAGE가 추가되는 경우

        if (["header", "footer"].contains(event)) {
            isPage = true;
        }

        //이벤트 추가
        var setFnEventListener = function (target, key) {
            eventList.push(this._parseCommand("btn-" + target + "-" + key));
            if (isPage) {
                eventList.push(this._parseCommand("btn-" + target + "-" + key) + "_PAGE");
            }
        }.bind(this)

        //custom은 넘어온 event function name 바로 사용하는 경우
        if (event == "custom") {
            eventList = keys;

            //타입 배열로 통일
            if (!Array.isArray(eventList)) {
                eventList = [eventList];
            }
        }
        else {
            if ($.isEmpty(subEvent)) {//버튼으로 판단되는 경우
                subEvent = "button";
            }
            //이벤트명 생성
            setFnEventListener(event, keys);
            if (subEvent) {
                setFnEventListener(subEvent, keys);
            }
        }

        for (var i = 0; i < eventList.length; i++) {
            this[eventList[i]] = function () {
                //중복체크
                if (this.isEventLoading()) {
                    return false;
                }

                this._isClickDelay = true;
                this.setTimeout(function () {
                    this._isClickDelay = false;
                }.bind(this), 100);

                var rtnValue = this.getEventCallbackHandler("click", keys, arguments);

                //return false인경우 다음 동작 event 동작할수 있도록 수정
                if (rtnValue === false) {
                    this._isClickDelay = false;
                }
            }
        }

        //단축키가 등록되어 있다면 설정
        if (shortCutKey) {
            this.addEventCallbackHandler(shortCutKey, keys, this[eventList[0]]);
        }
    },


4. 그리드 하단의 합계를 표시하는 방법은?
ecmodule.inputGrid.prod.js
if (this.pageOption.columnMap.grid[value].sum == true) {
    sumObj[this.pageOption.columnMap.grid[value].id] = { actionType: "sum" };
}