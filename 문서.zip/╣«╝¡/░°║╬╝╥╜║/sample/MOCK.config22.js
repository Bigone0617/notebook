

/**
 * MOCK - FrontEnd Integrated?Development Environment
 * 
 * __MOCK_CONFIG - 컨피그 정보, 모든 페이지 요청시 추가된다. 경로는 무조건 풀 패스 (/ECERP, /MOCK)
 * __MOCK_OPTION - dataCtrl, pageCtrl 정보
 * option host 없을경우 __EC_MOCK_CONFIG.host 값 추가
 * mockup.cshtml - DefaultViewPage 아니면 무조건 세팅
 * postDataDecorator
 *      - 목업일경우 - __MOCK_DATA=JSON.stringify(postDataDecorator())
 *      - 목업아닐때 - post data로 postDataDecorator() 리턴값 전송
 */
ecount.env.mock.register({
	host: "test.ecounterp.com",	//
	MOCKMap: {
		page: {
			"/ECERP/EBA/EBA063P_01" : {option:{
				pageCtrl: "/MOCK/sample/XESJ010M.js"
			}
		},
			"/SVC/ESG/ESG010M": {
				mockup: {
					type: "default",
					cshtml: "", //DefaultViewPage 아니면 무조건 세팅
					css: "",

				},
				option: {
					host: "test.ecounterp.com",
					dataCtrl: "testdata.js"
				},
				postDataDecorator: function (param) {
					//목업일경우 - __MOCK_DATA=JSON.stringify(postDataDecorator());
					//목업아닐때 - post data로 postDataDecorator() 리턴값 전송
				}
			},
			"/ECERP/SVC/ESD/ESD006M": {
				// mockup: {
				// 	type: "default",
				// },
				option: {
					//dataCtrl: "/MOCK/sample/XESD006M.datactrl.js",
					pageCtrl: "/MOCK/sample/EBA063P_01.js"
				}
			},
			"/ECERP/SVC/ESD/ESD007M": {
				// mockup: {
				// 	type: "default",
				// },
				option: {
					//dataCtrl: "/MOCK/sample/XESD006M.datactrl_1.js",
					pageCtrl: "/MOCK/sample/EBA068M.js"
				}
			},	
			"/ECERP/SVC/ESD/ESD006M11111": {
				mockup: {
					type: "default",
					cshtml: "", //DefaultViewPage 아니면 무조건 세팅
					css: ""
				},
				option: {
					dataCtrl: "/MOCK/tutorial/XESD006M.datactrl.js",
					pageCtrl: "/MOCK/tutorial/XESD006M.js"
				},
				postDataDecorator2: function (param) {
					//목업일경우 - __MOCK_DATA=JSON.stringify(postDataDecorator());
					//목업아닐때 - post data로 postDataDecorator() 리턴값 전송
					var __MOCK_DATA = {
						"CustomViewData": [
							{
								"Method": "list", //or "list" 
								"FormData": {
									"FormType": "MO001",
									"FormSeq": "1",
									"SetManuallyOption": {
										"ViewType": "R", //R:조회 I:입력
										"DetailOption": [
											{
												"ColCd": "COL_CD_01",
												"ColNm": "COL_NM_01",
												"ControlType": "widget.input.general",
												"DataType": "TEXT",
												"FieldSize": "150"
											},
											{
												"ColCd": "COL_CD_02",
												"ColNm": "COL_NM_02",
												"ControlType": "widget.input.general",
												"DataType": "TEXT",
												"FieldSize": "150"
											},
											{
												"ColCd": "COL_CD_03",
												"ColNm": "COL_NM_03",
												"ControlType": "widget.input.general",
												"DataType": "TEXT",
												"FieldSize": "150"
											},
											{
												"ColCd": "COL_CD_04",
												"ColNm": "COL_NM_04",
												"ControlType": "widget.input.general",
												"DataType": "TEXT",
												"FieldSize": "150"
											},
											{
												"ColCd": "COL_CD_05",
												"ColNm": "COL_NM_05",
												"ControlType": "widget.input.general",
												"DataType": "TEXT",
												"FieldSize": "150"
											}
										]
									}
								}
							}
						]
					};
					var mockdata = {
						__MOCK_DATA: __MOCK_DATA//Object.toJSON(viewCtrl)
					}
					return mockdata;
				}
			},
			//"/ECERP/SVC/ESD/ESD007M": { option: {} },
			"/ECERP/SVC/ESD/ESD007M1111": {
				option: {
					dataCtrl: "/MOCK/tutorial/form/XESD007M.datactrl.js",
					pageCtrl: "/MOCK/tutorial/form/XESD007M.js"
				}
			},

			"/ECERP/SVC/ESD/ESD005M": { option: {} },
			//"/ECERP/SVC/EBD/EBD010M_09": {option:{}}
			"": null
		},
		api: {
			"22222/ECAPI/SVC/Common/SlipTransfer/GetListXFormSlipCommon": {
				host: "test-dev.ecounterp.com",
				status: 200,
				url: "/MOCK/tutor/TestSaveApi.aspx",
				filter: function (param) { }
			}
		}
	}
});