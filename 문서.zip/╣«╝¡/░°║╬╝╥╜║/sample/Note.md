* 01 ~ 04 폴더 : 서버 코어 코드
* 07 폴더 : 프런트 실무 코드 (여기에서 작업)
* 08 폴더 : 서버에 반영되는 코드 (작업 x)
* 80 폴더 : 프런트 코어 코드

* 07 수정 후 80폴더를 다시 빌드 => 반영

* window.viewBag[id] : 서버에서 보내주는 데이터
* viewBag.InitDatas or viewBag.DefualtOption : 서버에서 내려준 데이터 확인할때 사용 

* this.ecPageId : 자신 페이지 아이디
* this.__ecPageId : 부모 페이지 아이디
* this.popupLevel : 페이지 레벨
* this.reponseId : 부모페이지의 헨들러

********************************************
https://devmanual.ecounterp.com/ : 위젯 문서 사이트
ECSolution\Master\80 Contents\WebResource\Contents\ui-test : 위젯 관련 소스
********************************************

================================================
MOCK환경 실행
1. https://loginba2-dev.ecounterp.com/ 로 로그인
2. F12후 콘솔창에 ecount.env.mock.load('/mock/폴더명');
3. 자신이 설정한 URL로 가서 테스트
================================================


* __self.pcid가 있으면 combine되어있다.


==================================================
설명 깃 주소 : http://git.ecount.kr/ecount/ecount-doc/tree/master/Manual/Eccomposite/kr
=====================================================