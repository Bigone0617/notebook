onInitHeader,onInitContents,onInitFooter : js가 실행될때 가장 먼저 실행되는 함수

* control
 - 선언 방법 : var control = widget.generator.control();
 - className이 'control'이라는 div생성

 * form
  - 선언 방법 : var form = widget.generator.form();

* Button
 - 선언 방법 : var button = control.define("widget.button","id","name");
 - button에 글씨 추가 : button.label("text");
 - 선언 후 마지막에 .end() 꼭 쓰기

* ButtonGroup
 - 선언 방법 : var buttonGroup = control.define("widget.button.group","id","name").label("label").addGroup([
   {label: "text", id : "id"},
   {label: "text", id : "id"},
   ...
 ])

* Input
 - 선언 방법 : var input = control.define("widget.input","id","name","title");
 - 선언 후 마지막에 .end() 꼭 쓰기

* Checkbox
 - 선언 방법 : var checkbox = control.define("widget.checkbox","id","name","title")
 - 라벨 : checkbox.label(["label1","label2","label3"]);
 - value : checkbox.value(["value1","value2","value3"]);
 - 선언 후 마지막에 .end() 꼭 쓰기

* Radio
 - 선언 방법 : var radio = control.define("widget.radio","id","name","title")
 - 라벨 : radio.label(["label1","label2","label3"]);
 - value : radio.value(["value1","value2","value3"]);
 - 선언 후 마지막에 .end() 꼭 쓰기

* Select
 - 선언 방법 : var select = control.define("widget.select","id","name","title")
 - option : select.option([["id1",""value1"],["id2",""value2"],["id3",""value3"]]);

* 단일입력(검색 포함) Code
 - 선언 방법 : control.define("widget.code.cust","id","name","title")

* 다중입력(검색 포함)
 1. cust
  - 선언 방법 : control.define("widget.multiCode.cust","id","name","title(주로 거래처)");
  2. prod
  - 선언 방법 : control.define("widget.multiCode.prod","id","name","title(주로 품목)");
  3. wh
  - 선언 방법 : control.define("widget.multiCode.wh","id","name","title(주로 창고)");

* onInitHeader 
 - 선언 방법 : onInitHeader(header){}
 - Title 선언 방법 : header.setTitle("title");
 - header에 위젯 붙이기 : header.add("widget");
 
* onInitContents 
 - 선언 방법 : onInitContents(contents){}
 - contents에 위젯 붙이기 : contents.add("widget");

* onInitFooter
 - 선언 방법 : onInitFooter(footer){}
 - footer에 위젯 붙이기 : footer.add("widget");

* function 네이밍
 - header에 search라는 id를 갖는 버튼을 누렀을때 작동하는 함수
 => onHeaderSearch = function(){}

 - footer에 save라는 id를 갖는 버튼을 누렀을때 작동하는 함수
 => onFooterSave = function(){}

* onChangeControl
 - 설명 : control에서 어떠한 change 발생했을때 작동하는 함수
 - 선언 방법 : onChangeControl : function(control){}

* onPopupHandler
 - 설명 : 팝업에 관련된 모든 이벤트를 조작하는 Handler
 - 선언 방법 : onPopupHandler : function(control, parameter, handler){
                    handler(parameter) ->  이걸 선언해줘야 팝업이 뜬다
            }

* sendMessage
 - 설명 : 부모 페이지에 데이터를 전송
 - 선언 방법 : Footer에서 id가 apply인 버튼을 눌렀을때 실행
 => onFooterApply : function(){
     var data = {
        extract : this.contents.extract() => extract라는 값에 contents 안에 있는 모든 UI정보를 저장
        save : this.contents.save() => save라는 값에 contents 안에 있는 데이터 값들을 저장
        serialize : this.contents.serialize() => serialize라는 값에 contents안에 있는 데이터 값들을 key,value로 저장
     }  
     this.sendMessage(this, data);
 }

* onMessageHandler
 - 설명 : 자식 페이지에서 전송한 데이터를 받음
 - 선언 방법 : onMessageHandler : function(context, data){
              this.contents.lastReset(data.extract.result) => 자식 페이지에서 받은 UI정보를 부모 페이지에 그대로 그림
              this.contents.restore(data.save) => 자식 페이지에서 받은 데이터를 부모 페이지에 입력
            }

* onLoadComplete
 - 설명 : 로딩 완료된 시점에 실행시키는 함수
 - 선언 방법 : onLoadComplete : function(){}

* .dataRules(); : 위젯에 어떠한 조건을 넣을때 사용
* this.contents.validate(); : dataRules를 호출

* onButtonID
 - 설명 : buttonGroup 안에 있는 버튼 클릭시 호출되는 함수
 - 선언 방법 : onButtonID : function(){}

===============================================================================
그리드

 * 그리드 : 위젯들이 모인 표
  - 버전이 3가지가 있음.
  - v2 : viewModel, view를 나눠 위젯 리팩토링과 같은 시기에 리팩토링 진행(header,body,footer로 나뉨)
  - 컬럼 : 고유한 키를 가지고 있음
  - 컬럼 속성 : id, propertyName, title, width, lineChange, datatype, controlOption 등등...

* column  
  - setColumns => js에서 직접 그리드를 그릴때
  - setFormData => api에서 컬럼 데이터를 받아서 그림
  - rowData => api 데이터 넣어주기

* row
  - 그리드를 그리는 실데이터 정보
  - rowId는 세팅을 안해줘도 됨
  - 기본값으로 index가 id로 됨

* propertyName
 - rowData가 세팅될 때 colums과 매칭하는 키값

* 그리드안에 있는 컨트롤들은 그리드에서 설정
* theaer, tbody, tfooter를 이용하여 컬럼들 속성 컨트롤 가능

* setCustomRowCell 
 - 그리드의 속성은 column정보에 담겨 있음.
 - 선언 방법 : .setCustomRowCell("id",function(value, rowItem){ 
  var option : {};
   return option;})

* setKeyColumn 
 - 컬럼에 키를 설정
 - 선언 방법 : .setKeyColumn('id')

* setCheckBoxUse
 - 그리드에 체크박스 표시
 - 선언 방법 : .setCheckBoxUse(true)

* setRowDataSample
 - 새로운 컬럼을 정적으로 생성할 때
 - 선언 방법 : .setRowDataSample({"columnId":"value","columnId2":"value2"})

* setRowData
 - 컬럼의 로우값 설정
 - 선언 방법 : .setRowData(로우데이터가 들어있는 변수) => 변수는 배열

* setCheckBoxUse
 - 체크 박스가 들어있는 컬럼 추가
 - 선언 방법: .setCheckBoxUse(use)

* setCheckBoxMaxCount
 - 체크 할 수 있는 체크박스 수 제한
 - .setCheckBoxMaxCount(5) => 5개만 체크 가능

* setCheckBoxMaxCountExceeded
 - 체크 박스 맥스이상으로 체크 할 시 호출되는 함수
 - 선언 방법 : .setCheckBoxMaxCountExceeded(function(){})

* setEventShadedColumnId
 - 클릭한 로우 값 음영처리
 - 선언 방법 : .setEventShadedColumnId('columnId')

* setCustomRowCell
 - 정적으로 어떠한 로우 값에 이벤트를 주거나 스타일 변경등 가능
 - 선언 방법 : .setCustomRowCell('columnId',function(){
   var options = {};
   //이벤트 추가
   options.event = {
     'click' : function(e,data){}
   },
    options.attrs = {}; ==>attrs 객체를 생성해줘야 스타일 및 
 })