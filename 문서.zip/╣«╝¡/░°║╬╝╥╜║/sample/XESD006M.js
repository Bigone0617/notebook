﻿/****************************************************************************************************
1. Create Date : 2018-04-03
2. Creator     : 허휘영
3. Description : 판매입력(Sale)
4. Precaution  :                
5. History     : 2018.09.18 (TanThanh) - Change function Copy to footer Copy button
                 2019.01.09 (HoangLinh): A18_04370_1 - Refactoring
                 2019.01.29 (PhiVo) A19_00340 - FE 리팩토링_페이지 일괄작업 5차 - apply method getFnItemById and not use method getFnItem in method save
                 2019.06.10 (AiTuan) - A18_01169 - 참조 공통화(판매입력)
                 2019.07.18 (AiTuan) - Set refTabId = this.tabIdList.main
                 2019.08.26 (허휘영) - 입력공통 리팩토링 단위 기능분리
                 2019.09.17 [LuongAnhDuy] A19_02831 -  재고 > 확인 권한이 있어도 미확인 전표수정시 미확인상태로 유지
6. MenuPath    : 재고1>영업관리>판매>판매입력
7. Old File    : View.ESD/XESD006M.js 
9. Etc         :  
****************************************************************************************************/
ecount.page.factory("ecount.page.common", "ESD006M", {
    /********************************************************************** 
    *   Init Data Setting function
    **********************************************************************/
    //page init event
    init: function (options) {
        //기본 전역변수 설정
        this.initDefaultPageData();
        alert(11);
        this._super.init.apply(this, arguments);
    },

    //page render event
    render: function () {
        //이벤트시에 사용하는 정보 function
        this.getActionCommonParam();

        this._super.render.apply(this);

        this.inputMainTab = this.getComposite("inputMainTab");

        //참조공통 탭 정보 추가
        this.refTabId = this.inputMainTab.tabIdList.main;
    },

    //기본 전역변수 설정
    initDefaultPageData: function () {
        //전표 정보
        this.slipInfo = {
            Master: {
                IO_DATE: "",
                IO_NO: 0,
                IO_TYPE: "",
                VERSION_NO: 0,
                R_FLAG: "2",            //기존 RType 
                CUST: "",
                CUST_DES: "",
                DEL_GUBUN: "N",
                DISCOUNT_YN: "N",
                EMP_CD: "",
                EMP_DES: "",
                WH_CD: "",
                WH_DES: "",
                WH_VAT_RATE: 0,
                WH_VAT_RATE_YN: "N",
                EXCHANGE_RATE: 0,
                EXCHANGE_TYPE: "",
                FAX_SEND_YN: null,
                FOREIGN_FLAG: "0",
                GB_TYPE: "Y",
                GUBUN: "",
                INFLOW: null,
                IN_PART: "00",
                OUTORDER_YN: "N",
                OUT_NO: null,
                OUT_PUSH_YN: false,
                PJT_CD: "",
                PJT_DES: "",
                PRICE_DISCOUNT_AMT: 0,
                P_DES1: "",
                P_DES2: "",
                P_DES3: "",
                P_DES4: "",
                P_DES5: "",
                P_DES6: "",
                QTY: 0,
                SALE_AMT: 0,
                SALE_AMT_F: 0,
                SEND_FLAG: null,
                UQTY: 0,
                VAT_AMT: 0,
                IoDateGoods: "",    //wiodate
                IoNoGoods: 0,        //wiono
                HID: ''
            }
        };

        //페이지 옵션 변수
        this.pageOption = {
            ///////////////////////////////// 페이지에서 초기화할 정보////////////////////////////////
            sale006Detail: null,                //sale006 table 정보(실제사용하는 변수는BAL_CHK_SALE 하나임 다른변수 다 지워도 될듯
            isViewFinishStepButton: false,      //처리단계 완료 버튼 표시 여부
            isDiscount: false,                 //할인적용여부 strDiscountYn
            IsInvoicing: false,             //회계반영여부

            //저장후 전달된 정보          
            returnCust: "", //TODO 수리입력에서 넘어오는 파라미터                    
            returnCustDes: "",
            returnWhCode: "",
            returnWhName: "",

            //회계에서 재고전표 연결했을때 추가 정보
            isLinkToInvoiceSlip: false,//회계전표에서 연결한 전표
            trxDateToInvoiceSlip: "",
            trxNoToInvoiceSlip: 0,
            accConfirmFlag: "N",
            linkHCustToInvoiceSlip: "",
        };
    },

    //서버에서 내려준 값 변수에 설정
    initProperties: function () {
        this.slipInfo = $.extend({}, this.slipInfo, this.viewBag.InitDatas.ViewData || {});
        $.extend(this.slipInfo.Master, this.slipInfo.Master.Key || {});

        //회계반영 정보 설정
        this.slipInfo.Master.R_FLAG = this.pageOption.R_FLAG;

        //출하지시서 정보 설정
        var _outOrder = this.viewBag.InitDatas.SlipRelationView.where(function (item) {
            return item.ProgramId == "E040220";//출하지시서
        }.bind(this))[0]

        this.outOrderInfo = {
            isOutOrderPush: !$.isEmpty(_outOrder.Datas),
            outOrderNo: $.isEmpty(_outOrder.Datas) ? 0 : _outOrder.Datas[0].No,
            isOutOrder: $.isEmpty(this.slipInfo.Master.OUTORDER_YN) ? false : this.slipInfo.Master.OUTORDER_YN == "Y"
        };

        //전표 불러오기 or 수정시에 데이터 설정
        if (
            this.pageOption.isSlipCopy || //전표복사
            this.pageOption.isSlipReturn || //반품처리
            this.pageOption.EditMode == ecenum.editMode.modify ||//수정모드
            this.getIsRelationFromProgramId(["E040904"/*오더관리*/, "E040304"/*구매*/, "E040204"/*주문서*/, "E040622"/*품질검사*/, "E040212"/*미판매*/, "E040230"/*주문서출고처리*/])//불러오기
        ) {
            this.pageHidden.modifyRowCount = ($.isEmpty(this.slipInfo.Details)) ? 0 : this.slipInfo.Details.length || 0;

            if (this.pageHidden.modifyRowCount > 0) {
                for (var i = 0; i < this.slipInfo.Details.length; i++) {
                    if (this.pageOption.EditMode == ecenum.editMode.modify || this.pageOption.isSlipCopy || this.pageOption.isSlipReturn) {
                        var relationView = this.viewBag.InitDatas.SlipRelationView;
                        if (this.pageOption.FromProgramId == "E010728"/*세금계산서*/ && this.pageOption.EcTaxEditMode == ecenum.editMode.modify) {
                            //수정세금계산서 판매수정 재오픈 시
                            //임시로 처리중인 연결관계에 따라 설정
                            if ($.isNull(this.pageOption.AmendedModifyRelation) == false) {
                                relationView = this.pageOption.AmendedModifyRelation;

                            }
                        }

                        //수정인 경우 Y => 체크로 변경
                        var wareMapping = relationView.where(function (item) { return item.ProgramId == "E040406" })[0];
                        if (wareMapping) {
                            this.slipInfo.Details[i].WARE_CHK = !wareMapping.Datas ? false : wareMapping.Datas.where(function (item) { return item.FromSer == this.slipInfo.Details[i].Key.SER_NO }.bind(this)).length > 0;
                        }

                        //출하지시서 매핑 여부
                        var shippingOrderMapping = relationView.where(function (item) { return item.ProgramId == "E040220" })[0];
                        if (shippingOrderMapping) {
                            this.slipInfo.Details[i].SHIPPINGORDER_CHK = !shippingOrderMapping.Datas ? false : shippingOrderMapping.Datas.where(function (item) { return item.FromSer == this.slipInfo.Details[i].Key.SER_NO }.bind(this)).length > 0;
                        }
                    }
                    else {
                        //신규시에는 기본 sc 설정값을 따라서 설정
                        if (this.slipInfo.Details[i].SET_FLAG == "1" || ["1", "2"].contains(this.slipInfo.Details[i].PROD_TYPE)) {
                            this.slipInfo.Details[i].WARE_CHK = ((ecount.config.inventory.PROD_SELL_YN == "Y" && this.slipInfo.Details[i].PROD_SELL_TYPE == "B") || this.slipInfo.Details[i].PROD_SELL_TYPE == "Y") ? true : false;
                        }

                        this.slipInfo.Details[i].SHIPPINGORDER_CHK = false;
                        //불러오기인 경우에 거래처 정보로 설정
                        if (!this.getIsRelationFromProgramId("")) {
                            this.slipInfo.Details[i].SHIPPINGORDER_CHK = this.outOrderInfo.isOutOrder;
                        }
                    }
                }
            }
        }

        //페이지 기초정보
        this.pageInfo = {
            name: "ESD006M",//현재 페이지 name
            path: "/ECERP/SVC/ESD/ESD006M",//현재페이지 url
            listPath: "/ECERP/SVC/ESD/ESD007M",//리스트 페이지 링크
            printPath: "/ECERP/SVC/ESD/ESD007R",//출력물 페이지 링크
            FORM_TYPE_INPUT: "SI030",//입력 양식코드
            FORM_TYPE_PRINT: "SF030",//인쇄 양식코드
            FORM_TYPE_GRID: "SI030",//그리드 양식코드
            SUBPROD_FORM_TYPE: "SD030",//상세품목 양식 코드
            LOAD_TO_TYPE: "490",//불러오기 to type
            IO_TYPE: "10",//내품목에서 사용하는 io_type
            WIO_TYPE: "43",//추가ioType(생산)
            MYPROD_FORM_SEQ: "3",//내품목에서 사용되는 품목양식seq
            MENU_AUTH: "SALE_CHK2",//메뉴권한설정
            SLIP_CD: "4130",//전표 코드
            menuTitle: ecount.resource.LBL15145,//에러공통팝업의 메뉴 명칭(판매)
            inputTitle: ecount.resource.LBL93316,//판매입력
            modifyTitle: ecount.resource.LBL02937,//판매수정
            SEL_CODE: "1",//거래내역보기팝업 페이지 구분자
            FM_TYPE: "BUY",//소요팝업 구분자
            CONSUMED_GUBUN: "1",//소요팝업 I_GUBUN과 동일한거 같은데 확인 필요 DEFAULT가 1
            CONSUMED_I_GUBUN: "1",//소요팝업 입력화면 구분(1:판매입력, 2:발주계획입력, 3:발주요청입력, 4:발주서입력)
            DOCNO_CODE_TYPE: "42",//코드타입
            SALEORDER_INPUT_TYPE: "1",//1:판매/2:구매요청서/3:작업지시서/4:창고이동/5:구매요청
            DOC_NO: this.pageOption.DocNo,//판매입력 문서번호
            DOC_TITLE: ecount.resource.LBL09161,//판매입력 문서번호 타이틀
            USE_CONFIRM: ecount.config.inventory.USE_CONFIRM_SALE,//확인/미확인 구분 
            USE_SLIPAUTH: ecount.config.user.USE_SLIPAUTH_SALE,//각전표 권한
            DOC_GUBUN: "214",//메일/문자/쪽지 발송 DOC_GUBUN
            HISTORY_TYPE: "03",//메일/문자/쪽지 발송 HISTORY_TYPE
            RPT_GUBUN: "SELL",//품목검색창 정보의 rpt_gubun 설정
            MenuTypeOfSafetyStock: "SELL",//안전재고 체크 구분자
            CollectiveFLAG: "SALE", //일괄 회계반영 페이지 구분자
            S_SYSTEM: "S",//회계에서 전표구분
            C_GUBUN: "40",//회계 C_GUBUN
            RECEIVE_FORM_SEQ: 0, //수신화면 양식 FORM_SEQ(알림위젯)
            RECEIVE_FORM_TYPE: "SJ030",//수신화면 양식 FORM_TYPE(알림위젯)
            permissions: this.viewBag.Permission.Self,//권한
            MAIN_CUST_CB: "1",//거래처 채권 MAIN_CUST_CB
            SUM_FLAG: "1",//거래처별 채권 SUM_FLAG
            useInvoice: true,//매출/매입 전표탭 사용여부
            SEARCH_TYPE: ecount.config.inventory.SEARCH_TYPE,//주문서 미현황 사용여부
            limitCheckUrl: "/Inventory/Common/CheckSaleLimit",//저장시 한도체크하는 api 설정(선택)
            USE_UQTY: ecount.config.inventory.USE_OUT_UQTY,//추가수량사용여부
            SAFETY_SET: ecount.config.inventory.SAFETY_SELL_SET,//안전재고 변수
            CUST_LIMIT: ecount.config.inventory.CUST_LIMIT,//여신한도 변수
            CUST_LIMIT_TERM: ecount.config.inventory.CUST_LIMIT_TERM,//여신기간 변수
            isNewLoadSlip: true,
            finishSlipLoad: {//종결 체크박스 설정을 위한 정보
                programIds: ["E040204"/*주문서*/, "E040212"/*미판매*/, "E040230"/*주문서출고처리*/],//불러오기대상 프로그램아이디
                checkboxTitle: ecount.resource.LBL03349,//체크박스명(주문종결)
                slipTitle: ecount.resource.LBL02585,//테이블내부 전표명(주문번호)
                permission: this.viewBag.Permission.saleOrder,//권한
                viewBagName: "LinkSaleOrder",//viewBag
                slipDate: "REQ_DATE",
                slipNo: "REQ_NO"
            },
            invoiceTabInfo: {
                "1": "E010301",
                "2": "E010201",
                "4": "E010311"
            },
            pageHeader: [
                {
                    group: "header", id: "header", templateType: "input-inventory-header", sortType: "input-inventory-header",
                    child: ["custCashIn"/*현금수급*/, "custNotesrec"/*어음수금*/]
                }
            ],
            pageContents: [{
                group: "inputContents", id: "contents",
                child: [
                    { group: "toolbar", type: "temporarySave" },
                    {
                        group: "tabContents", type: "inputMainTab", id: "inputMainTab", child: [
                            { group: "form", type: "inv" },
                            {
                                group: "toolbar", id: "loadSlip", templateType: "input-inventory-contentsLoadSlip", sortType: "input-inventory-gridButtonDefault",
                                child: ["viewTrans"/*거래내역보기*/, "myprodLoad"/*내품목*/, "viewInvQty"/*재고불러오기*/,"consumed"/*소요*/, "saleOrderLoad"/*주문*/, "purchasesLoad"/*구매*/, "discount"/*할인*/],
                            },
                            {
                                group: "toolbar", id: "prodCheck", templateType: "input-inventory-contentsProdCheck", sortType: "input-inventory-gridButtonCheck", hidden: true,
                                child: ["f4"/*f4*/, "bom"/*상세bom*/, "priceChange"/*단가변경*/, "expenses"/*부대비용*/,]
                            },
                            { group: "grid", type: "prod", functions: ["calc"] },
                        ]
                    }
                ],
            }],
            pageFooter: [
                {
                    group: "footer", id: "footer",
                    child: [
                        { group: "toolbar", id: "footerToolbarTop", templateType: "input-inventory-footerTop", sortType: "input-inventory-footerTop" },
                        {
                            group: "toolbar", id: "footerToolbarDefault", templateType: "input-inventory-footerMain", sortType: "input-inventory-footer",
                            child: ["changeMake2", "ectaxSave", "acctConnection", "slipReturn"]
                        }
                    ]
                }
            ],
            pageFunction: [
                { function: "inputEvent" }
            ],

            isNowConfirmStatus: this.getIsNowConfirmStatus(),//현재 전표 확인/미확인 확인인지 여부
            isCollectiveInvoicing: this.getIsCollectiveInvoicing(),//일괄회계반영인지 여부
            isLoadAccountChecked: this.getIsLoadAccountChecked(),////페이지로드시 회계전표 체크 여부 기본값
            isAcctSlipConfirmCancel: this.getIsAcctSlipConfirmCancel(),//회계반영 취소 가능 여부 반환
            nowGbTypeStatus: this.getNowGbTypeStatus(),//현재 GBType 를 반환
        }

        if (this.pageOption.EditMode == ecenum.editMode.new) {
            //통화 위젯 기본값 : 환율정보(불러오기등 정보 설정)
            if (this.viewBag.InitDatas.ViewData) {
                if ($.isEmpty(this.slipInfo.Master.IO_TYPE)) {
                    var deioTypes = this.viewBag.InitDatas.ViewData.Master.IO_TYPE;
                    this.slipInfo.Master.IO_TYPE = $.isEmpty(deioTypes) ? ecount.config.inventory.OUT_TYPE : deioTypes;
                }
            }
        }

        //생산전표 정보 설정
        this.slipInfo.Master.IoDateGoods = this.slipInfo.Master.W_IO_NO || 0 != 0 ? this.slipInfo.Master.IO_DATE || "" : "";
        this.slipInfo.Master.IoNoGoods = this.slipInfo.Master.W_IO_NO || 0;

        //창고 부가세율
        this.pageHidden.customerType = $.isEmpty(this.pageOption.customerType) ? "" : this.pageOption.customerType;

        //삭제 컨펌창에 체크박스 추가
        this.pageHidden.checkbox = ["checkbox", ecount.resource.LBL17399];

        //매출전표 포함 삭제여부
        this.pageHidden.AccountDeleteFlag = false;

        //일괄회계반영, 회계전표연결에서 넘어온 거래처 List
        this.pageHidden.acctCustList = [];

        //회계전표연결에서 넘어온 회계전표금액
        this.pageHidden.accountAmt = null;

        //회계전표연결팝업에서 저장할 경우
        this.pageHidden.isLinkWithAcct = false;

        //회계전표연결팝업에서 넘어온 연결관계
        this.pageHidden.saveSlipRelation = [];

        //생산 relation 정보
        var produceData = this.viewBag.InitDatas.SlipRelationView.where(function (item) {
            return item.ProgramId == "E040406";//생산입고1
        }.bind(this))[0];

        //출하 relation 정보
        var shippingorderData = this.viewBag.InitDatas.SlipRelationView.where(function (item) {
            return item.ProgramId == "E040220";//출하지시서
        }.bind(this))[0];

        //밀어주기 탭에 대한 정보 설정
        this.pageInfo.tabidListData = {
            E040406: {//생산
                EditMode: !$.isEmpty(produceData.Datas) ? ecenum.editMode.modify : ecenum.editMode.new,
                id: "ware_chk",//그리드 밀어주기 대상 품목 선택 셀 id
                columnName: ecount.resource.LBL01533,
                param: function (EditMode) {//밀어주기 페이지로드시 param
                    var data = { EditMode: ecenum.editMode.new };
                    if ((EditMode == ecenum.editMode.modify || this.pageOption.isSlipCopy || this.pageOption.isSlipReturn) && produceData.Datas) {
                        var editMode = this.pageOption.isSlipCopy ? ecenum.editMode.copy : this.pageOption.isSlipReturn ? ecenum.editMode.return : ecenum.editMode.modify
                        data = {
                            Request: {
                                Key: {
                                    Date: this.slipInfo.Master.IO_DATE,
                                    No: produceData.Datas[0].No
                                },
                                FromProgramId: this.viewBag.ProgramInfo.PROGRAM_ID,
                                EditMode: editMode,
                            }
                        }
                    }
                    return data;
                }.bind(this),
                tabSync: {//탭 동기화
                    grid: {
                        //동기화 조건
                        where: function (rowItem) {
                            //체크가 되지 않은경우 선택하지 않음
                            if (rowItem["WARE_CHK"] == false) {
                                return false;
                            }
                            //셋트 or 제품,반제품만 등록 가능
                            if (rowItem.SET_FLAG == "1" || ["1", "2"].contains(rowItem.PROD_TYPE)) {
                                return true;
                            }
                            else {
                                return false;
                            }
                        }.bind(this),
                        //기본 체크 여부
                        defaultChecked: function (rowItem) {
                            //셋트,제품,반재품인지 체크
                            if (rowItem.SET_FLAG == "1" || ["1", "2"].contains(rowItem.PROD_TYPE)) {
                                //판매에서 생산 밀어주기 기본값인지 체크
                                if ((ecount.config.inventory.PROD_SELL_YN == "Y" && rowItem.PROD_SELL_TYPE == "B") || rowItem.PROD_SELL_TYPE == "Y") {
                                    return "check";
                                }
                                else {
                                    return "uncheck";
                                }
                            }

                            return "not";
                        }.bind(this),
                        useTabShowByProdAppend: true,
                        isDisableCell: true,
                    }
                }
            },
            E040220: {//출하
                EditMode: this.outOrderInfo.outOrderNo > 0 ? ecenum.editMode.modify : ecenum.editMode.new,
                id: "shippingOrder_chk",
                columnName: ecount.resource.LBL03962,
                param: function (EditMode) {//밀어주기 페이지로드시 param
                    var data = { EditMode: ecenum.editMode.new };
                    if ((EditMode == ecenum.editMode.modify || this.pageOption.isSlipCopy || this.pageOption.isSlipReturn) && shippingorderData.Datas) {
                        var editMode = this.pageOption.isSlipCopy ? ecenum.editMode.copy : this.pageOption.isSlipReturn ? ecenum.editMode.return : ecenum.editMode.modify
                        data = {
                            Request: {
                                Key: {
                                    Date: this.slipInfo.Master.IO_DATE,
                                    No: this.outOrderInfo.outOrderNo,
                                },
                                FromProgramId: this.viewBag.ProgramInfo.PROGRAM_ID,
                                EditMode: editMode,
                            }
                        }
                    }
                    return data;
                }.bind(this),
                tabSync: {//탭 동기화
                    grid: {
                        isTabLoadAllChecked: true,
                        //동기화 조건
                        where: function (rowItem) {
                            //체크가 되지 않은경우 선택하지 않음
                            if (rowItem.SHIPPINGORDER_CHK == false) {
                                return false;
                            }
                            return true;
                        }.bind(this),
                        //기본 체크 여부
                        defaultChecked: function (rowItem) {
                            return "check";
                        }.bind(this)
                    }
                }
            }
        }
    },

    //api 통신을 위한 파라미터 설정
    getActionCommonParam: function () {
        this.pageInfo.params = {
            header: {
                //확인,확인/취소 api
                confirm: function () {
                    var data = {
                        param: {
                            Request: {
                                Data: {
                                    Key: {
                                        Date: this.slipInfo.Master.IO_DATE,
                                        No: this.slipInfo.Master.IO_NO
                                    },
                                    Version: this.slipInfo.Master.VERSION_NO,
                                },
                                EditMode: this.pageOption.slipGbType == "N" ? ecenum.editMode.confirm : ecenum.editMode.confirmCancel,
                                PermissionRange: this.execCallback(function () {
                                    return {
                                        WriterID: this.slipInfo.WriterID,
                                        WriterInPart: this.slipInfo.WriterInPart,
                                        EditorID: this.slipInfo.EditorID,
                                        EditorInPart: this.slipInfo.EditorInPart
                                    };
                                }.bind(this)),
                            }
                        }
                    };
                    data.url = "/SVC/Inventory/Sale/Confirm";
                    return data;
                }.bind(this),
            },
            contents: {
                //시리얼 체크
                serialChk: function () {
                    var data = {
                        checkData: {
                            isResidualQuantity: true,
                            RedundancySerial: true,
                            WhCd: this.getControls("wh_cd").getValue(0),
                            IO_TYPE: this.getControls("io_type").getValue(),
                            IO_DATE: this.getControls("basic_date").getDateFormat("yyyyMMdd").first() || "",
                            //CHECK_TYPE: this.pageHidden.saveTypeOrigin
                        },
                        keys: ["FROM_QTY", "FROM_SERIAL"],
                    }

                    return data;
                }.bind(this),
            },
            footer: {
                //이력보기
                history: function () {
                    return {
                        url: "/ECERP/Popup.Search/ES303P",
                        param: {
                            historySlipDate: this.slipInfo.Master.IO_DATE,
                            historySlipNo: this.slipInfo.Master.IO_NO,
                            menuType: "03",
                            serNo: "-1",
                            isParentHistoryListFlag: true,
                            lastData: String.format("{0}[{1}]", this.slipInfo.Master.WDATE, this.slipInfo.Master.WID)
                        }
                    }
                }.bind(this),
                //삭제취소 안전재고 체크
                cancelChk: function () {
                    var data = {};
                    var qtyLimit = [];
                    data.url = "/Inventory/Common/CheckSaleLimit";//안전재고체크 url

                    //안전재고 체크 파라미터 리턴
                    //수정모드인경우 수정정보 정리
                    if (this.viewBag.InitDatas.ViewData.Details.length > 0) {
                        var details = this.viewBag.InitDatas.ViewData.Details
                        for (var i = 0; i < details.length; i++) {
                            var sQty = "";
                            if (new Decimal(details[i].QTY || "0").isZero() == false)
                                sQty = details[i].QTY;
                            else {
                                sQty = $.isEmpty(details[i].QTY) != true ? "0" : "";
                            }

                            qtyLimit.push({
                                ProdCd: details[i].PROD_CD,
                                Qty: sQty,
                                WhCd: this.getControls("wh_cd").getValue(),
                                ProdDes: details[i].PROD_DES,
                                BalFlag: details[i].BAL_FLAG,
                                WareFlag: details[i].WARE_CHK == true ? "Y" : "N",
                                TYPE: "A0002"
                            });
                        }
                    }

                    //전표정보 확인
                    var liotypes = "10",
                        liodate = "",
                        liono = "0";
                    if (this.pageOption.EditMode == ecenum.editMode.modify) {
                        liotypes = this.slipInfo.Master.IO_TYPE;
                        liodate = this.slipInfo.Master.IO_DATE;
                        liono = this.slipInfo.Master.IO_NO;
                    }

                    if (this.getControls("foreign_type").getForeign() == "0") {
                        this.getControls("foreign_type").setValue(1, "0");
                    }

                    var limitParam = {
                        //안전재고 체크시
                        MenuTypeOfSafetyStock: this.pageInfo.MenuTypeOfSafetyStock,
                        SafetyStockDto: {
                            CUST: this.getControls("cust", null, "getValue") || "",
                            EditFlag: this.pageOption.EditMode == ecenum.editMode.new ? "I" : "M",
                            DecQty: this.getComposite("grid").qtyDecimal,
                            WareFlag: this.getControls("createGoodsReceiptSlip", null, "getValue") == true ? "Y" : "N",
                            IoNoTypeKey: {
                                IO_DATE: liodate,
                                IO_TYPE: liotypes,
                                IO_NO: liono
                            },
                            DecreaseDetail: qtyLimit
                        }
                    }

                    //안전재고체크 파라미터
                    data.param = limitParam;

                    return data;
                }.bind(this),
                //삭제취소api
                cancel: function () {
                    var data = {};
                    data.deleteCancelCheck = this.pageInfo.permissions.Value;//권한체크
                    data.param = JSON.stringify({//삭제취소 저장 api 파라미터
                        IoType: this.slipInfo.Master.IO_TYPE,
                        IoDate: this.slipInfo.Master.IO_DATE,
                        IoNo: this.slipInfo.Master.IO_NO
                    });

                    data.url = "/Inventory/Sale/DeleteCancel";//삭제취소 저장 api url
                    return data;
                }.bind(this),
                //삭제 api
                delete: function () {
                    var data = {
                        param: {
                            Request: {
                                Data: {
                                    Key: {
                                        Date: this.slipInfo.Master.IO_DATE,
                                        No: this.slipInfo.Master.IO_NO
                                    },
                                    LinkToInvoiceSlipInfo: null,
                                    Version: this.slipInfo.Master.VERSION_NO,
                                    AccountDeleteFlag: this.pageHidden.AccountDeleteFlag,
                                    IsCollectiveInvoicing: this.getIsCollectiveInvoicing(),
                                    Cust: null
                                },
                                EditMode: ecenum.editMode.delete,
                                SaveSlipRelations: null,
                                PermissionRange: this.execCallback(function () {
                                    return {
                                        WriterID: this.slipInfo.WriterID,
                                        WriterInPart: this.slipInfo.WriterInPart,
                                        EditorID: this.slipInfo.EditorID,
                                        EditorInPart: this.slipInfo.EditorInPart
                                    };
                                }.bind(this)),
                            }
                        },
                        url: "/SVC/Inventory/Sale/Delete"
                    };

                    if (this.pageHidden.AccountDeleteFlag == false && this.getIsCollectiveInvoicing() == true && this.contents.getTabContents().getTabs().isShowTab(this.inputMainTab.tabIdList.invoice)) {
                        var details = this.setDeleteCollectiveInvoicing();
                        data.param.Request.SaveSlipRelations = this.getSaveSlipRelationsByPage(details, true);
                        data.param.Request.Data.LinkToInvoiceSlipInfo = this.getLinkToInvoiceSlipInfo(details);
                        data.param.Request.Data.Cust = this.getControls("cust").getValue();
                    }

                    return data;
                }.bind(this),
                //저장 api 
                save: function () {
                    //매출전표 구분
                    var AccountViewFlag = "";
                    if (this.inputMainTab.getAccountViewFlag()) {
                        AccountViewFlag = this.inputMainTab.getAccountViewFlag().flag;
                    }

                    ////////////////////////////////////////////////////////////////////////////////////////////////////
                    ///////////////////////////////          판매 상단 정보 설정         ///////////////////////////////
                    ////////////////////////////////////////////////////////////////////////////////////////////////////
                    //회계반영 여부
                    var IsInvoicing = this.pageOption.isLinkToInvoiceSlip == true ? false : this.pageOption.IsInvoicing == true ? true : false;
                    var IsCollectiveInvoicing = this.getIsCollectiveInvoicing();
                    var tmpMasterIoDate = this.getControls("basic_date").getDateFormat("yyyyMMdd").first();
                    var tmpMasterIoNo = this.slipInfo.Master.IO_NO || 0;

                    //수정세금계산서 + 수정일 때. IO_NO, DATE
                    //if (this.getIsRelationFromProgramId("E010728")/*세금계산서*/) {
                    //    tmpMasterIoDate = this.ioNoTypeKey.Date;
                    //    tmpMasterIoNo = this.ioNoTypeKey.No;
                    //}

                    var transRelationInfo = { TransRelData: [] };

                    if (this.slipInfo.Master.ASO_SLIP_TYPE_CD != undefined && this.slipInfo.Master.ASO_SLIP_TYPE_CD != null) {
                        transRelationInfo.TransRelData.push({
                            ASO_SLIP_TYPE_CD: this.slipInfo.Master.ASO_SLIP_TYPE_CD,
                            TRANS_REL_PRG_ID: this.slipInfo.Master.TRANS_REL_PRG_ID,
                            TRANS_REL_DATE: this.slipInfo.Master.TRANS_REL_DATE,
                            TRANS_REL_NO: this.slipInfo.Master.TRANS_REL_NO,
                            TRANS_REL_SER_NO: this.slipInfo.Master.TRANS_REL_SER_NO,
                            TO_SER: 0,
                        });
                    }

                    var SaleSaveMaster = {
                        Key: {
                            IO_DATE: tmpMasterIoDate,
                            IO_NO: tmpMasterIoNo
                        },
                        HID: this.slipInfo.Master.HID,
                        IO_DATE: tmpMasterIoDate,
                        IO_NO: tmpMasterIoNo,
                        IO_TYPE: this.getControls("io_type").getValue(),
                        CUST: this.getControls("cust").getValue(),
                        CUST_DES: this.getControls("cust").getValue(1),
                        WH_CD: this.getControls("wh_cd").getValue(),
                        PJT_CD: this.getControls("pjt_cd") && this.getControls("pjt_cd").getValue(),
                        EMP_CD: this.getControls("emp_cd") && this.getControls("emp_cd").getValue(),
                        FOREIGN_FLAG: this.getControls("foreign_type") && this.getControls("foreign_type").getForeign(),
                        EXCHANGE_TYPE: this.getControls("foreign_type") && this.getControls("foreign_type").getForeign() == "1" ? this.getControls("foreign_type").getForeignCode() : "",
                        EXCHANGE_RATE: this.getControls("foreign_type") && this.getControls("foreign_type").getValue(1),
                        P_DES1: this.getControls("u_memo1") && this.getControls("u_memo1").getText(),
                        P_DES2: this.getControls("u_memo2") && this.getControls("u_memo2").getText(),
                        P_DES3: this.getControls("u_memo3") && this.getControls("u_memo3").getText(),
                        P_DES4: this.getControls("u_memo4") && this.getControls("u_memo4").getText(),
                        P_DES5: this.getControls("u_memo5") && this.getControls("u_memo5").getText(),
                        P_DES6: this.getControls("u_txt1") && this.getControls("u_txt1").getValue(),
                        DISCOUNT_YN: this.pageOption.isDiscount == true || this.pageOption.isDiscount == "Y" ? "Y" : "N",
                        PRICE_DISCOUNT_AMT: this.pageOption.priceDiscontAmt || 0,
                        TRX_DATE: IsInvoicing ? this.getControls("trx_date", this.inputMainTab.tabIdList.invoice).getDate().first().format("yyyyMMdd") : "", //IsInvoicing ? $("#syear").val() + $("#smonth").val().DateAddZero() + $("#sday").val().DateAddZero() : "",
                        GB_TYPE: this.getNowGbTypeStatus(),
                        VERSION_NO: this.slipInfo.Master.VERSION_NO || 0,

                        GB_TYPE_OLD: this.pageOption.slipGbType,
                        //**checkpoint getLoadWidgetData 제거해도 되는지 확인 서버에서 사용하지 않는것으로 보임
                        IO_TYPE_OLD: this.slipInfo.Master.IO_TYPE,

                        ASO_SLIP_TYPE_CD: this.slipInfo.Master.ASO_SLIP_TYPE_CD,
                        TRANS_REL_PRG_ID: this.slipInfo.Master.TRANS_REL_PRG_ID,
                        TRANS_REL_DATE: this.slipInfo.Master.TRANS_REL_DATE,
                        TRANS_REL_NO: this.slipInfo.Master.TRANS_REL_NO,
                        TRANS_REL_SER: this.slipInfo.Master.TRANS_REL_SER,
                    };

                    if (this.getIsRelationFromProgramId("E060906")) {
                        SaleSaveMaster.INFLOW = "C";
                        SaleSaveMaster.SlipCallers = this.slipInfo.Master.SlipCallers;
                    }

                    if (this.pageOption.FromProgramId == "E010728"/*세금계산서*/) {
                        SaleSaveMaster.W_IO_NO = this.slipInfo.Master.IoNoGoods;
                    }

                    var OutProcKeyData = [];

                    //주문서출고처리키 정보
                    if (this.sale031_OutProcKey != null && this.sale031_OutProcKey.length > 0) {
                        var tmpOutProcDate = '', tmpOutProcNo = '';
                        for (var i = 0; i < this.sale031_OutProcKey.length; i++) {
                            if (tmpOutProcDate != this.sale031_OutProcKey[i].OUTPROC_DATE || tmpOutProcNo != this.sale031_OutProcKey[i].OUTPROC_NO) {
                                OutProcKeyData.push({
                                    OUTPROC_DATE: this.sale031_OutProcKey[i].OUTPROC_DATE, OUTPROC_NO: this.sale031_OutProcKey[i].OUTPROC_NO
                                });
                                tmpOutProcDate = this.sale031_OutProcKey[i].OUTPROC_DATE;
                                tmpOutProcNo = this.sale031_OutProcKey[i].OUTPROC_NO;
                            }
                        }
                    }

                    ////////////////////////////////////////////////////////////////////////////////////////////////////
                    ///////////////////////////////          판매 하단 정보 설정         ///////////////////////////////
                    ////////////////////////////////////////////////////////////////////////////////////////////////////

                    var acctTrxDate = "";
                    var acctTrxNo = 0
                    if ($.isNull(this.viewBag.InitDatas.SlipRelationView) == false) {
                        var slipRelationAccount = this.viewBag.InitDatas.SlipRelationView.where(function (x) {
                            return x.HasRelated == true && x.Group == "10";
                        });

                        if (slipRelationAccount.length > 0 && !$.isEmpty(slipRelationAccount[0])) {
                            acctTrxDate = slipRelationAccount[0].Datas[0].Date;
                            acctTrxNo = slipRelationAccount[0].Datas[0].No;
                        }
                    }

                    var mapping = function (i, item) {
                        //품목코드와 수량(0도 입력으로 판단)이 입력되지 않으면 종료
                        if ($.isEmpty(item.PROD_CD) || $.isEmpty(item.QTY)) {
                            return null;
                        }

                        if (item.ASO_SLIP_TYPE_CD != undefined && item.ASO_SLIP_TYPE_CD != null) {
                            var detail = {
                                ASO_SLIP_TYPE_CD: item.ASO_SLIP_TYPE_CD,
                                TRANS_REL_PRG_ID: item.TRANS_REL_PRG_ID,
                                TRANS_REL_DATE: item.TRANS_REL_DATE,
                                TRANS_REL_NO: item.TRANS_REL_NO,
                                TRANS_REL_SER_NO: item.TRANS_REL_SER_NO,
                                TO_SER: item[ecount.grid.constValue.displayRowNumberingPropertyName],
                            }
                            transRelationInfo.TransRelData.push(detail);
                        }

                        var saleSubProdDatas = new Array();
                        var serialIdx = item.SERIAL_IDX || "";
                        if (!$.isEmpty(serialIdx))
                            serialIdx = serialIdx.substring(serialIdx.length - 1, serialIdx.length) == "ㆍ" ? serialIdx.substring(0, serialIdx.length - 1) : serialIdx;

                        if ($.isEmpty(item.SUB_PROD_DATA) != true) {
                            $.each(item.SUB_PROD_DATA, function (e, sIubtem) {
                                saleSubProdDatas.push({
                                    PROD_CD: sIubtem.PROD_CD || "",
                                    PROD_DES: sIubtem.PROD_DES || "",
                                    SIZE_DES: sIubtem.SIZE_DES || "",
                                    UQTY: sIubtem.UQTY,
                                    QTY: sIubtem.QTY,
                                    REMARKS: sIubtem.REMARKS || "",
                                    P_AMT1: sIubtem.P_AMT1,
                                    P_AMT2: sIubtem.P_AMT2,
                                    P_AMT3: sIubtem.P_AMT3,
                                    P_REMARKS1: sIubtem.P_REMARKS1 || "",
                                    P_REMARKS2: sIubtem.P_REMARKS2 || "",
                                    P_REMARKS3: sIubtem.P_REMARKS3 || "",
                                    WRITER_ID: sIubtem.WRITER_ID,
                                    WRITE_DT: sIubtem.WRITE_DT,
                                    EDITOR_ID: sIubtem.EDITOR_ID,
                                    EDIT_DT: sIubtem.EDIT_DT,
                                });
                            })
                        };

                        var retdto = {
                            IO_TYPE: SaleSaveMaster.IO_TYPE,
                            PROD_CD: item.PROD_CD || "",
                            PROD_DES: item.PROD_DES || "",
                            SIZE_DES: item.SIZE_DES || "",
                            UQTY: item.UQTY,
                            QTY: item.QTY,
                            PRICE: item.PRICE,
                            USER_PRICE_VAT: item.USER_PRICE_VAT || "0",
                            SUPPLY_AMT: item.SUPPLY_AMT,
                            SUPPLY_AMT_F: null,
                            VAT_AMT: item.VAT_AMT,
                            TOT_AMT: null,
                            ITEM_CD: item.ITEM_CD || "",
                            REMARKS: item.REMARKS || "",
                            REQ_DATE: item.REL_DATE || "",
                            REQ_NO: item.REL_NO,
                            P_AMT1: item.P_AMT1,
                            P_AMT2: item.P_AMT2,
                            P_REMARKS1: item.P_REMARKS1 || "",
                            P_REMARKS2: item.P_REMARKS2 || "",
                            P_REMARKS3: item.P_REMARKS3 || "",
                            WARE_CHK: item.WARE_CHK == true ? "Y" : "N",
                            SERIAL_IDX: serialIdx,
                            SERIAL_KEY: item.SERIAL_KEY,
                            SERIAL_DATE: this.pageOption.serialTime,
                            CUST: SaleSaveMaster.CUST || "",
                            CUST_DES: SaleSaveMaster.CUST_DES || "",
                            PJT_CD: SaleSaveMaster.PJT_CD || "",
                            EMP_CD: SaleSaveMaster.EMP_CD || "",
                            BOM_NO: item.BOM_NO_DEFAULT,
                            R_FLAG: item.R_FLAG || "",
                            TRX_DATE: IsCollectiveInvoicing ? item.TRX_DATE : (IsInvoicing ? this.getControls("trx_date", this.inputMainTab.tabIdList.invoice).getDate().first().format("yyyyMMdd") : ""),
                            TRX_NO: IsCollectiveInvoicing ? item.TRX_NO : (IsInvoicing ? acctTrxNo : 0),
                            CONFIRM_FLAG: IsCollectiveInvoicing ? item.CONFIRM_FLAG : null,
                            SUB_PROD_DATA: saleSubProdDatas,
                            CUST_AMT: item.CUST_AMT,
                            PRICE_DISCOUNT_STAND: item.PRICE_DISCOUNT_STAND || 0,
                            PRICE_VAT_DISCOUNT_STAND: item.PRICE_VAT_DISCOUNT_STAND || 0,
                            BAL_FLAG: item.BAL_FLAG || "",
                            INSERT_TYPE: this.pageOption.EditMode == ecenum.editMode.modify ? "U" : "I",
                            Key: { SER_NO: item[ecount.grid.constValue.displayRowNumberingPropertyName] },

                            ASO_SLIP_TYPE_CD: item.ASO_SLIP_TYPE_CD,
                            TRANS_REL_PRG_ID: item.TRANS_REL_PRG_ID,
                            TRANS_REL_DATE: item.TRANS_REL_DATE,
                            TRANS_REL_NO: item.TRANS_REL_NO,
                            TRANS_REL_SER: item.TRANS_REL_SER,
                            UNIT: item.UNIT
                        };

                        if (this.pageOption.FromProgramId == "E010728"/*세금계산서*/) {
                            retdto.TRX_DATE = item.TRX_DATE;
                            retdto.TRX_NO = item.TRX_NO;
                        }

                        if (IsCollectiveInvoicing || this.pageHidden.isLinkWithAcct) {
                            retdto.CONFIRM_FLAG = item.CONFIRM_FLAG;
                        }

                        if ($.isNull(retdto.TRX_DATE) || $.isNull(retdto.TRX_NO)) {
                            retdto.TRX_DATE = "";
                            retdto.TRX_NO = 0;
                            retdto.CONFIRM_FLAG = 0;
                        }
                        return retdto;

                    }.bind(this)

                    //전표 하단 수정한 대상만 조회
                    var itemList = this.getComposite("grid").getSaveRowData({
                        mapping: mapping
                    });

                    var result = {
                        Request: {
                            EditMode: this.pageOption.EditMode,
                            SaveSlipRelations: null,
                            Data: {
                                AccountViewFlag: AccountViewFlag,

                                //=====================================
                                // 판매
                                //=====================================

                                //---------------------------------
                                // Option
                                //---------------------------------
                                //회계반영-미처리전표 사용여부
                                PassApp: ecount.user.PASS_APP,
                                //회계반영-미처리전표 사용여부
                                UseConfirm: ecount.config.company.USE_SLIP_CONFIRM,
                                //금액소수점 자리수
                                DecAmt: ecount.config.company.DEC_AMT,
                                //시리얼 사용여부
                                UseSerial: ["Y", "M"].contains(ecount.config.inventory.USE_SERIAL) ? true : false,
                                //수정시 원본 하단 라인수
                                ModifyRowCountOrigin: this.pageOption.EditMode == ecenum.editMode.modify ? this.pageHidden.modifyRowCount : 0,
                                //기존회계전표일자
                                TrxDateOrigin: acctTrxDate || "",
                                //기존회계전표번호
                                TrxNoOrigin: acctTrxNo,
                                //회계에서 판매 연결
                                LinkToInvoiceSlipInfo: [{
                                    isLinkToInvoiceSlip: this.pageOption.isLinkToInvoiceSlip,
                                    trxDateToInvoiceSlip: this.pageOption.trxDateToInvoiceSlip,
                                    trxNoToInvoiceSlip: this.pageOption.trxNoToInvoiceSlip,
                                    accConfirmFlag: this.pageOption.accConfirmFlag,
                                    linkHCustToInvoiceSlip: this.pageOption.linkHCustToInvoiceSlip,
                                    programId: this.pageOption.FromProgramId
                                }],
                                //---------------------------------
                                // 전잔금액
                                //---------------------------------
                                BeginningAmt: this.pageHidden.BeginningAmt,
                                //---------------------------------
                                // Master
                                //---------------------------------
                                Master: SaleSaveMaster,

                                //---------------------------------
                                // Details
                                //---------------------------------
                                Details: itemList,

                                //---------------------------------
                                // Additional Field
                                //---------------------------------
                                AdditionalField: {
                                    //전잔금액                                    
                                    Field1: {
                                        //추가항목1 잔액표기설정
                                        Type: this.getComposite("u_memo1").getTopBalanceType().balType,
                                        //추가항목1 잔액표기설정 문자식
                                        Calc: this.getComposite("u_memo1").getTopBalanceType().calcValue,
                                        //추가항목1 재계산여부
                                        IsRecalculate: this.getControls("u_memo1") && this.getControls("u_memo1").getFnItemById("recalculateu_memo1") && this.getControls("u_memo1").getFnItemById("recalculateu_memo1").getValue() || (this.pageOption.EditMode == ecenum.editMode.new),
                                    },
                                    Field2: {
                                        //추가항목2 잔액표기설정
                                        Type: this.getComposite("u_memo2").getTopBalanceType().balType,
                                        //추가항목2 잔액표기설정 문자식
                                        Calc: this.getComposite("u_memo2").getTopBalanceType().calcValue,
                                        //추가항목2 재계산여부
                                        IsRecalculate: this.getControls("u_memo2") && this.getControls("u_memo2").getFnItemById("recalculateu_memo2") && this.getControls("u_memo2").getFnItemById("recalculateu_memo2").getValue() || (this.pageOption.EditMode == ecenum.editMode.new),
                                    },
                                    Field3: {
                                        //추가항목3 잔액표기설정
                                        Type: this.getComposite("u_memo3").getTopBalanceType().balType,
                                        //추가항목3 잔액표기설정 문자식
                                        Calc: this.getComposite("u_memo3").getTopBalanceType().calcValue,
                                        //추가항목3 재계산여부
                                        IsRecalculate: this.getControls("u_memo3") && this.getControls("u_memo3").getFnItemById("recalculateu_memo3") && this.getControls("u_memo3").getFnItemById("recalculateu_memo3").getValue() || (this.pageOption.EditMode == ecenum.editMode.new),
                                    },
                                    Field4: {
                                        //추가항목4 잔액표기설정
                                        Type: this.getComposite("u_memo4").getTopBalanceType().balType,
                                        //추가항목4 잔액표기설정 문자식
                                        Calc: this.getComposite("u_memo4").getTopBalanceType().calcValue,
                                        //추가항목4 재계산여부
                                        IsRecalculate: this.getControls("u_memo4") && this.getControls("u_memo4").getFnItemById("recalculateu_memo4") && this.getControls("u_memo4").getFnItemById("recalculateu_memo4").getValue() || (this.pageOption.EditMode == ecenum.editMode.new),
                                    },
                                    Field5: {
                                        //추가항목5 잔액표기설정
                                        Type: this.getComposite("u_memo5").getTopBalanceType().balType,
                                        //추가항목5 잔액표기설정 문자식
                                        Calc: this.getComposite("u_memo5").getTopBalanceType().calcValue,
                                        //추가항목5 재계산여부
                                        IsRecalculate: this.getControls("u_memo5") && this.getControls("u_memo5").getFnItemById("recalculateu_memo5") && this.getControls("u_memo5").getFnItemById("recalculateu_memo5").getValue() || (this.pageOption.EditMode == ecenum.editMode.new),
                                    }
                                },

                                //---------------------------------
                                // 일괄회계반영여부
                                //---------------------------------
                                IsCollectiveInvoicing: IsCollectiveInvoicing,

                                //---------------------------------
                                // 회계연결전표여부
                                //---------------------------------
                                IsLinkWithAcct: false,

                                //---------------------------------
                                // 매출전표1
                                //---------------------------------
                                Invoice1: null,

                                //---------------------------------
                                // 매출전표2
                                //---------------------------------
                                Invoice2: null,

                                //---------------------------------
                                // 매출전표3
                                //---------------------------------
                                Invoice3: null,

                                //---------------------------------
                                // 출하지시서 / footer check 시 객체 전달 아니면 null
                                //---------------------------------
                                ShippingOrder: null,

                                //---------------------------------
                                // 생산입고 / footer check 시 객체 전달 아니면 null
                                //---------------------------------
                                GoodsReceipt: null,

                                //---------------------------------
                                // 주문 출고 키
                                //---------------------------------
                                OutProcKey: OutProcKeyData,

                                //---------------------------------
                                // 주문서종결
                                //---------------------------------
                                SaleOrderFinishs: this.execCallback(function () {
                                    var saleOrderFinishs = [];

                                    if (this.getControls("finishSlipLoad", null, "getValue") == true
                                        && this.footer.getControl("finishSlipLoad").getLayerListSelectedValue().length > 0) {
                                        var list = this.footer.getControl("finishSlipLoad").getLayerListSelectedValue();
                                        for (var i = 0; i < list.length; i++) {
                                            saleOrderFinishs.push({
                                                Date: list[i].Date,
                                                No: list[i].No
                                            });
                                        }
                                    }
                                    return saleOrderFinishs;
                                }.bind(this))
                            },

                            //--------------------------------
                            // 불러오기 연관전표 파라미터 설정
                            //---------------------------------
                            TransRelationInfoRequest: transRelationInfo,
                        }
                    };

                    var page = this.inputMainTab.getPageInvoice();
                    var invoiceData;
                    if ($.isEmpty(page) == false) {
                        invoiceData = this.inputMainTab.getAcctInvoiceData();
                    }

                    if (IsCollectiveInvoicing == false) {
                        switch (AccountViewFlag) {
                            case "1":
                                result.Request.Data.Invoice1 = invoiceData;
                                break;
                            case "2":
                                result.Request.Data.Invoice2 = invoiceData;
                                break;
                            case "4":
                                result.Request.Data.Invoice3 = invoiceData;
                                break;
                        }
                    }

                    //자식 페이지 하단 매핑
                    var mappingItemList = this.getComposite("grid").getSaveRowData({
                        isMapping: true,
                        mapping: mapping
                    });

                    var tabIdList = this.inputMainTab.tabIdList;
                    //=====================================
                    // 출하지시서 페이지 밀어주기 파라미터 설정
                    //=====================================
                    if (tabIdList.E040220 && this.contents.getTabContents().getTabs().isShowTab(tabIdList.E040220)) {
                        result.Request.Data.ShippingOrder = {};

                        var page = this.contents.getPage(this.pageInfo.tabidListData[tabIdList.E040220].pageId);
                        if (page && page.getComposite && page.getComposite("inputEvent")) {
                            //출하지시서에서 페이지 데이터 파라미터 호출
                            var saveDataParam = page.getComposite("inputEvent").getSaveData(mappingItemList.list);
                            result.Request.Data.ShippingOrder = saveDataParam.Request;
                            result.Request.Data.ShippingOrder.EditMode = result.Request.Data.ShippingOrder.Data.EditMode;
                        }
                    }

                    //=====================================
                    // 생산전표 페이지 밀어주기 파라미터 설정
                    //=====================================
                    if (tabIdList.E040406 && this.contents.getTabContents().getTabs().isShowTab(tabIdList.E040406)) {
                        result.Request.Data.GoodsReceipt = {};
                        var page = this.contents.getPage(this.pageInfo.tabidListData[tabIdList.E040406].pageId);
                        if (page && page.getSaveData) {
                            //생산입고1에서 페이지 데이터 파라미터 호출
                            var saveDataParam = page.getSaveData(mappingItemList.list, "MakeDetails");
                            result.Request.Data.GoodsReceipt = saveDataParam.Request;
                            result.Request.Data.GoodsReceipt.EditMode = result.Request.Data.GoodsReceipt.Data.EditMode;
                        }
                    }

                    //=====================================
                    // 일괄회계반영, 라인별회계반영 연결정보 파라미터 설정
                    //=====================================

                    if (this.pageHidden.isLinkWithAcct ||
                        (IsCollectiveInvoicing == true &&
                            (this.contents.getTabContents().getTabs().isShowTab(this.inputMainTab.tabIdList.invoice) ||
                                this.pageOption.FromProgramId == "E010728"/*세금계산서*/))
                    ) {
                        var details = null;

                        result.Request.Data.IsLinkWithAcct = this.pageHidden.isLinkWithAcct;

                        if (this.pageOption.EditMode == ecenum.editMode.new || IsCollectiveInvoicing == false)
                            details = this.pageHidden.saveSlipRelation;
                        else
                            details = this.checkCollectiveInvoicing(result.Request.Data.IsLinkWithAcct);

                        if (!$.isEmpty(details)) {
                            result.Request.SaveSlipRelations = this.getSaveSlipRelationsByPage(details);
                            result.Request.Data.LinkToInvoiceSlipInfo = this.getLinkToInvoiceSlipInfo(details);
                        }
                    }

                    var rtnData = {
                        url: "/SVC/Inventory/Sale/Save",
                        param: result,
                    };

                    return rtnData;
                }.bind(this),

                //부모페이지 
                saveSendParent: function () {
                    switch (this.pageOption.FromProgramId) {
                        case "E010728"://세금계산서
                            //수정세금계산서인 경우, Action에 대한 결과를 호출페이지에 전달
                            return {
                                action: this._LAST_ACTION_TYPE,
                                result: this.pageOption.asyncApiStep.getTemp()
                            };
                            break;
                        case ecount.programId.Inventory.WmsReceive://WMS 입출고
                        case ecount.programId.Inventory.WmsReleaseAllocate:

                            var saveResult = this.pageOption.asyncApiStep.getTemp();

                            var resultData = {
                                IO_DATE: saveResult.IoDate,
                                IO_NO: saveResult.IoNo,
                                IO_TYPE: "04",
                                programId: this.viewBag.ProgramInfo.PROGRAM_ID,
                                slipCd: "04"
                            };

                            var param = {
                                MODIFY_TYPE: "modify",
                                callback: null,
                                data: resultData
                            }

                            return param;
                            break;
                    }

                    //조건에 해당되지 않는경우 null 리턴
                    return null;
                }.bind(this)
            }
        }
    },

    /********************************************************************** 
    *   common option function 
    **********************************************************************/
    //페이지로드시 회계전표 체크 여부 기본값
    getIsLoadAccountChecked: function () {
        //전표별 자동으로 회계반영 설정이 아니면 종료
        if (!ecount.config.inventory.USE_SELL_AUTOACCOUNT) {
            return false;
        }

        //수정세금계산서(판매만 입력) 인 경우 종료
        if (this.pageOption.FromProgramId == "E010728"/*세금계산서*/) {
            return false;
        }

        return true;
    },

    //회계반영 여부 반환
    getIsViewAccountingReflects: function () {
        //확인 미확인 기능이 미확인인 경우 종료
        if (!this.getIsNowConfirmStatus()) {
            return false;
        }

        //회계전표 정보 설정
        var acctTrxNo = 0;
        if ($.isNull(this.viewBag.InitDatas.SlipRelationView) == false) {
            var slipRelationAccount = this.viewBag.InitDatas.SlipRelationView.where(function (x) {
                return x.HasRelated == true && x.Group == "10";
            });

            if (slipRelationAccount.length > 0 && !$.isEmpty(slipRelationAccount[0])) {
                acctTrxNo = slipRelationAccount[0].Datas[0].No;
            }
        }

        //자동회계반영 이면서 수정모드, 회계반영 취소가 불가능한 경우 종료
        if (!ecount.config.inventory.USE_BALANCE_BASIS && this.pageOption.EditMode == ecenum.editMode.modify && this.getIsAcctSlipConfirmCancel()) {
            return false;
        }

        //회계전표가 연결되지 않았고, 회계(매출전표1, 2, 3)권한이 하나도 없는경우 종료
        if (acctTrxNo == 0 && !this.inputMainTab.getInvoicePermissionsPageNumber()) {
            return false;
        }

        //매출전표에 연결되고, 회계(매출전표1, 2, 3)권한이 하나도 없는경우 종료
        if (acctTrxNo > 0 && !this.inputMainTab.getAccountViewFlag(["1", "2", "4"], ["W", "U"])) {
            return false;
        }

        //생산전표가 연결되고, 생산 쓰기권한이 없는경우 종료
        if (this.slipInfo.Master.IoNoGoods > 0 && this.viewBag.Permission.goodsReceipt.Value != "W") {   //this.permissions.goodsReceipt.CU
            return false;
        }

        //회계에서 연결된 전표인지 여부
        if (this.pageOption.isLinkToInvoiceSlip) {
            return false;
        }

        return true;
    },

    //회계반영 취소 가능 여부 반환
    getIsAcctSlipConfirmCancel: function () {
        //수정모드가 아니면 항상 가능(새로 반영된 회계반영)
        if (this.pageOption.EditMode == ecenum.editMode.new) {
            return true;
        }

        //회계전표 정보 설정
        var acctTrxDate = "";
        var acctTrxDateCancelOrigin = "";
        if ($.isNull(this.viewBag.InitDatas.SlipRelationView) == false) {
            var slipRelationAccount = this.viewBag.InitDatas.SlipRelationView.where(function (x) {
                return x.HasRelated == true && x.Group == "10";
            });

            if (slipRelationAccount.length > 0 && !$.isEmpty(slipRelationAccount[0])) {
                acctTrxDate = slipRelationAccount[0].Datas[0].Date;
                acctTrxDateCancelOrigin = slipRelationAccount[0].Datas[0].Date;
            }
        }

        //회계반영이 되어있으면 종료
        if (!$.isEmpty(acctTrxDate) || !$.isEmpty(acctTrxDateCancelOrigin)) {
            return false;
        }

        //편집제한일자보다 일자가 작은 전표면 종료
        if ($.parseNumber(Date.format("yyyyMMdd", ecount.config.inventory.LIMIT_DATE)) > $.parseNumber(this.slipInfo.Master.IO_DATE)) {
            return false;
        }

        //전표 권한 체크(전체권한 > 전표 권한 > 판매 권한)
        if (!(ecount.config.user.SLIP_PER_TYPE == "1" ? true : (ecount.config.user.SLIP_AUTH_TYPE == "4" ? false : ecount.config.user.USE_SLIPAUTH_SALE))) {
            return false;
        }

        return true;
    },

    //일괄회계반영인지 여부 변환
    getIsCollectiveInvoicing: function () {
        //회계전표 정보 설정
        var acctTrxNo = 0;
        if ($.isNull(this.viewBag.InitDatas.SlipRelationView) == false) {
            var slipRelationAccount = this.viewBag.InitDatas.SlipRelationView.where(function (x) {
                return x.HasRelated == true && x.Group == "10";
            });

            if (slipRelationAccount.length > 0 && !$.isEmpty(slipRelationAccount[0])) {
                acctTrxNo = slipRelationAccount[0].Datas[0].No;
            }
        }

        return this.slipInfo.Master.R_FLAG == "2" && acctTrxNo > 0
    },

    //현재 GBType 를 반환 
    getNowGbTypeStatus: function () {
        var flag = false; // 회계연결전표 팝업에서 넘어왔을때 모두 연결끊기인 경우
        if (this.pageHidden.isLinkWithAcct && this.pageOption.EditMode != ecenum.editMode.new) {
            var disconnectList = this.pageHidden.saveSlipRelation.where(function (x) { return x.EditMode == ecenum.editMode.disconnect });

            if (disconnectList.length == this.pageHidden.saveSlipRelation.length) {
                flag = true;
            }
        }

        //수정세금계산서는 form 확인/미확인 정보로 저장
        if (this.pageOption.FromProgramId == "E010728"/*세금계산서*/) {
            return this.pageOption.slipGbType;
        }

        //확인/미확인 사용여부 : 사용안하는경우 Y
        if (this.pageOption.EditMode == ecenum.editMode.new) {
            if (!ecount.config.user.USE_CONFIRM_SALE)
                return "Y";
            else
                return "N";
        }

        //라인별회계반영에서 넘어온 경우
        if (this.pageHidden.isLinkWithAcct == true && flag == false) {
            return "Y";
        }

        //수정시 확인미확인 기능 사용인 경우 기본값 N으로 반환
        // 회계반영이 되어 있을 경우 미확인으로 돌아가지 않는다
        if (ecount.config.inventory.USE_CONFIRM_EDIT_SALE && $.isEmpty(this.pageHidden.saveSlipRelation) && (this.pageOption.IsInvoicing == false && this.getIsCollectiveInvoicing() == false)) {
            return "N";
        }

        // 회계전표연결팝업에서 넘어온 경우 모두 연결끊기 일때 기본값 N으로 반환
        if (ecount.config.inventory.USE_CONFIRM_EDIT_SALE && flag) {
            return "N";
        }

        //저장된값 그대로 사용
        return this.pageOption.slipGbType;
    },

    //현재 전표 확인/미확인 확인인지 여부 반환
    getIsNowConfirmStatus: function () {
        //수정인경우 저장된 구분 반환
        if (this.pageOption.EditMode == ecenum.editMode.modify) {
            return this.pageOption.slipGbType == "Y";
        }

        //확인/미확인 사용인경우
        if (ecount.config.user.USE_CONFIRM_SALE) {
            return false;
        }
        else {
            return true;
        }
    },

    onInitGroupTabContentsInputMainTab: function () {
        var option = {
            isOverriding: true,
            getAcctInvoiceData: function () {//회계데이터 가져오기
                var page = this.getLayout("contents").getPage(this.getAccountViewFlag().name);
                var invoiceData = page && page.getSaveData();

                if (this.pageInfo.isCollectiveInvoicing == true) return invoiceData;

                invoiceData.Request.Acc100.FOREIGN_FLAG = this.getControls("foreign_type").getValue().replace(RegExp(ecount.delimiter, "g"), "/");

                return invoiceData.Request;
            }

        };

        return option;
    },

    /********************************************************************** 
    *  page code
    **********************************************************************/

    getLinkToInvoiceSlipInfo: function (invoiceData) {
        var linkToInvoiceSlipInfo = [];

        var acctGroup = invoiceData.groupBy(function (x) { return x.TRX_DATE + "-" + x.TRX_NO });

        for (var key in acctGroup) {
            if (acctGroup.hasOwnProperty(key) == false)
                continue;

            var acct = acctGroup[key];
            var editMode = ecenum.editMode.disconnect;
            var checkSellSlip = false;

            // 회계전표와 연결돼있는 판매하단 중 connect가 하나라도 있으면 connect로 취급
            // 단, 매출전표포함 삭제일 경우는 제외
            if (this.pageHidden.AccountDeleteFlag == false) {
                $.each(acct, function (i, x) {
                    if (!$.isNull(x.TrxEditMode) && x.TrxEditMode == ecenum.editMode.connect)
                        editMode = ecenum.editMode.connect;
                    else if (x.EditMode == ecenum.editMode.connect)
                        editMode = ecenum.editMode.connect;
                });
            }

            var obj = {
                isLinkToInvoiceSlip: true,
                trxDateToInvoiceSlip: key.split("-")[0],
                trxNoToInvoiceSlip: key.split("-")[1],
                accConfirmFlag: acctGroup[key][0].GB_TYPE,
                programId: acctGroup[key][0].programId,
                EditMode: editMode,
                CheckSellSlip: true
            }

            linkToInvoiceSlipInfo.push(obj);
        }

        return linkToInvoiceSlipInfo;
    },

    getSaveSlipRelationsByPage: function (invoiceData) {
        var SaveSlipRelations = [];

        $.each(invoiceData, function (i, detail) {
            SaveSlipRelations.push({
                FROM_PRG_ID: this.viewBag.ProgramInfo.PROGRAM_ID, //판매
                FROM_SLIP_DATE: detail.IO_DATE,
                FROM_SLIP_NO: detail.IO_NO,
                FROM_SER_NO: detail.SER_NO,
                FROM_GB_TYPE: detail.GB_TYPE,
                ACCT_CUST: detail.CUST,
                TO_PRG_ID: detail.programId,
                TO_SLIP_DATE: detail.TRX_DATE,
                TO_SLIP_NO: detail.TRX_NO,
                EditMode: detail.EditMode
            });
        }.bind(this));

        return SaveSlipRelations;
    },

    setDeleteCollectiveInvoicing: function () {
        var result = [];
        var invoiceData = this.inputMainTab.getAcctInvoiceData();

        $.each(invoiceData, function (i, invoice) {
            var trxEditMode = ecenum.editMode.disconnect;
            if (this.pageHidden.AccountDeleteFlag == true || (invoice.IO_DATE == this.ioNoTypeKey.Date && invoice.IO_NO == this.ioNoTypeKey.No)) {
                if (this.pageHidden.AccountDeleteFlag == false) {
                    var trxDate = invoice.TRX_DATE;
                    var trxNo = invoice.TRX_NO;
                    var sellGroup = invoiceData.where(function (x) { return x.TRX_DATE == trxDate && x.TRX_NO == trxNo }).groupBy(function (x) { return x.IO_DATE + '-' + x.IO_NO });

                    if (Object.keys(sellGroup).length > 1)
                        trxEditMode = ecenum.editMode.connect;
                }
                invoice.EditMode = ecenum.editMode.disconnect;
                invoice.TrxEditMode = trxEditMode;
                result.push(invoice);
            }
        }.bind(this));

        return result;
    },

    checkCollectiveInvoicing: function (isLinkWithAcct) {
        var result = [];
        //회계반영된 하단 list
        var linkedDetails = this.getGrid().getRowList().where(function (x) { return x.TRX_DATE != "" && x.TRX_NO != 0 });

        //하단 list
        var details = this.getGrid().getRowList().where(function (x) { return x.PROD_CD != "" });

        var invoiceData;

        if (this.pageOption.FromProgramId == "E010728"/*세금계산서*/) {
            invoiceData = this.pageOption.AmendedCollectInvoice.select(function (data) {
                return _.extend(data, { programId: data.PROGRAM_ID, CUST: data.ACCT_CUST });
            });
        } else {
            invoiceData = this.inputMainTab.getAcctInvoiceData();
        }

        // result에 key 가 같고 editMode가 각각, connect, disconnect 두개 들어있을경우 서버에서 한 개의 키만 사용하고 editMode를 slipUpdate로 변경함 
        // slipUpdate는 연결관계가 바뀌지 않는 경우를 의미함
        $.each(invoiceData, function (i, invoice) {
            // 현재 판매전표가 아닐경우 return
            if (!(invoice.IO_DATE == this.ioNoTypeKey.Date && invoice.IO_NO == this.ioNoTypeKey.No)) {
                return;
            }

            // 물려있는 회계전표가 다른 판매와 연결돼있는지 체크
            var trxEditMode = ecenum.editMode.disconnect;
            var trxDate = invoice.TRX_DATE;
            var trxNo = invoice.TRX_NO;
            var sellGroup = invoiceData.where(function (x) { return x.TRX_DATE == trxDate && x.TRX_NO == trxNo }).groupBy(function (x) { return x.IO_DATE + '-' + x.IO_NO });

            if (Object.keys(sellGroup).length > 1)
                trxEditMode = ecenum.editMode.connect;

            invoice.TrxEditMode = trxEditMode;

            // 처음 수정화면에 나타난 하단 기준으로 editMode를 disconnect로 하여 push
            var _invoice = _.cloneDeep(invoice);
            _invoice.EditMode = ecenum.editMode.disconnect;
            result.push(_invoice);

            // 판매전표 화면에서 저장했을경우
            if (isLinkWithAcct == false) {
                // 저장 버튼 누른 시점 판매전표 하단 기준으로 하단이 존재하면 connect로 result에 push
                var cur = linkedDetails.where(function (x) { return x.KEY.IO_DATE == invoice.IO_DATE && x.KEY.IO_NO == invoice.IO_NO && x.KEY.SER_NO == invoice.SER_NO });
                if (cur != null && cur.length > 0) {
                    invoice.EditMode = ecenum.editMode.connect;
                    var __invoice = _.cloneDeep(invoice);
                    result.push(__invoice);
                }
            }
        }.bind(this));

        // 회계전표연결 팝업에서 넘어온 경우 connect 된 연결정보는 아래에서 정리한다.
        // 이유는 판매하단을 추가하고 회계전표연결 팝업에서 회계반영 했을 경우 위 반복문에서는 처리할수 없기 때문이다.
        if (isLinkWithAcct == true && !$.isEmpty(this.pageHidden.saveSlipRelation)) {
            $.each(this.pageHidden.saveSlipRelation, function (i, detail) {
                if (detail.TRX_DATE == "" || detail.TRX_NO == 0) {
                    return;
                }

                result.push(detail);
            }.bind(this));
        }

        var _result = _.cloneDeep(result);

        //현재 화면의 판매하단전표에 대한 SER_NO 정리
        $.each(details, function (i, detail) {
            var idx = -1;

            // 화면기준 회계반영된 하단이 아닐경우 return
            if (detail.TRX_DATE == "" || detail.TRX_NO == 0)
                return;

            for (var j = 0, len = _result.length; j < len; j++) {
                if (_result[j].EditMode == ecenum.editMode.disconnect)
                    continue;

                var obj = _result[j];
                if (detail.KEY.IO_DATE == obj.IO_DATE && detail.KEY.IO_NO == obj.IO_NO && detail.KEY.SER_NO == obj.SER_NO) {
                    idx = j;
                    break;
                }
            }

            if (idx != -1) {
                result[idx].SER_NO = i + 1;
            }
        }.bind(this));

        return result;
    },

    checkCustForCollectiveInvoicing: function () {
        // 거래처 체크하는거 만들어줘야함. 회계전표연결에서 넘어온 경우에도

        var linkedDetails = this.getGrid().getRowList().where(function (x) { return x.TRX_DATE != "" && x.TRX_NO != 0 });
        // 회계전표연결로 넘어온 경우
        if (this.pageHidden.isLinkWithAcct) {

            $.each(this.pageHidden.saveSlipRelation, function (i, detail) {
                if (detail.TRX_DATE == "" || detail.TRX_NO == 0)
                    return;

                this.pageHidden.acctCustList.push(detail.CUST);
            }.bind(this));

        } else { // 일괄회계반영 전표 저장인 경우
            var invoiceData = this.inputMainTab.getAcctInvoiceData();

            // result에 key 가 같고 editMode가 각각, connect, disconnect 두개 들어있을경우 서버에서 한 개의 키만 사용하고 editMode를 slipUpdate로 변경함 
            // slipUpdate는 연결관계가 바뀌지 않는 경우를 의미함
            $.each(invoiceData, function (i, invoice) {
                var cur = linkedDetails.where(function (x) { return x.KEY.IO_DATE == invoice.IO_DATE && x.KEY.IO_NO == invoice.IO_NO && x.KEY.SER_NO == invoice.SER_NO });
                if (cur != null && cur.length > 0) {
                    this.pageHidden.acctCustList.push(invoice.CUST);
                }
            }.bind(this));
        }

        var invCust = this.getControls("cust").getValue();
        var otherCust = this.pageHidden.acctCustList.where(function (x) { return x != invCust });

        if ($.isEmpty(otherCust)) {
            // 판매 거래처와 다른 거래처가 없을경우 그냥 판매 거래처 반환
            return invCust;
        } else {
            // 판매 거래처와 다른 거래처가 있을경우 첫번째 거래처 반환
            return otherCust[0];
        }
    },

    //RelationFromProgramId가 있는지 여부
    getIsRelationFromProgramId: function (programIds) {
        if (!Array.isArray(programIds)) {
            programIds = [programIds];
        }

        if (this.pageOption.EditMode == ecenum.editMode.new) {
            return programIds.contains(this.pageOption.RelationFromProgramId);
        }

        return false;
    },     
});
