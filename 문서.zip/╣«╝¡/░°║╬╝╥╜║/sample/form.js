/****************************************************************************************************
1. Create Date : 2018-04-03
2. Creator     : 허휘영
3. Description : 판매입력(Sale)
4. Precaution  :                
5. History     : 2018.09.18 (TanThanh) - Change function Copy to footer Copy button
                 2019.01.09 (HoangLinh): A18_04370_1 - Refactoring
                 2019.01.29 (PhiVo) A19_00340 - FE 리팩토링_페이지 일괄작업 5차 - apply method getFnItemById and not use method getFnItem in method save
                 2019.06.10 (AiTuan) - A18_01169 - 참조 공통화(판매입력)
                 2019.07.18 (AiTuan) - Set refTabId = this.tabIdList.main
                 2019.08.26 (허휘영) - 입력공통 리팩토링 단위 기능분리
                 2019.09.17 [LuongAnhDuy] A19_02831 -  재고 > 확인 권한이 있어도 미확인 전표수정시 미확인상태로 유지
6. MenuPath    : 재고1>영업관리>판매>판매입력
7. Old File    : View.ESD/XESD006M.js 
9. Etc         :  
****************************************************************************************************/
ecount.page.factory("ecount.page", "EBA068M", {
    /********************************************************************** 
    *   Init Data Setting function
    **********************************************************************/
    //page init event
    init: function (options) {
        
        this._super.init.apply(this, arguments);
        this.__ecPageID = this.pageID+"_1";
    },

    //page render event
    render: function () {
        this._super.render.apply(this, arguments);
    } ,
    //contents에 있는 컨트롤 받아오기
    getControlList : function(contents){
        controlList = [];
        console.log(contents.items);
        if(contents.items[0]){
            contents.items[0].rows.forEach(item => {
                controlList.push(item);
            })
        }
        console.log(controlList);
        return controlList;
    },

    onInitHeader: function(header){
        header.setTitle("EBA068M");

        // var control = widget.generator.control();

        // //tab
        // var tabContents = widget.generator.tabContents();
        // var contents = widget.generator.contents();

        // tabContents
        //         .setFormInfo(this.viewBag.FormInfos.formSearch)
        // //this.viewBag.FormInfos.formSearch : 양식 정보
        // contents.add(tabContents);
        // header.addContents(contents);
    },
    onHeaderSearch : function(){
        this.openWindow()
    },

    onInitContents: function(contents){
        var form = widget.generator.form();
        var inputList = this.createContentsWidget("input",4,"거래처");

        var contorl = widget.generator.control();

        form.add(contorl
                .define("widget.checkbox","chk1","CHK_NAME","선택항목")
                .label(["전체","본문","답글"])
                .value(["all","1","0"])
                .end()
            )
        form.add(contorl
            .define("widget.radio","chk2","CHK_NAME","선택항목")
            .label(["전체","본문","답글"])
            .value(["all","1","0"])
            .end()
        )
        form.add(contorl
            .define("widget.select","chk3","CHK_NAME","선택항목")
            .option([["all","전체"],["1","본문"],["0","답글"]])
            .end()
        )
        form.add(contorl
            .define("widget.code.cust","cust","CHK_NAME","선택항목")
            .end()
        )
        form.add(contorl
            .define("widget.multiCode.cust","multiCodeCust","cust_NAME","거래처")
            .end()
        )
        form.add(contorl
            .define("widget.multiCode.prod","multiCodeProd","prod_NAME","품목")
            .end()
        )
        form.add(contorl
            .define("widget.multiCode.wh","multiCodeWh","wh_NAME","창고")
            .end()
        )

        form.setFormId("ecountContentsForm")
            .add(inputList[0])
            .add(inputList[1])
            .add(inputList[2])
            .add(inputList[3]);

        contents.add(form);
    },
    onPopupHandler: function(control, parameter, handler){
        //isApplyDisplayFlag
        console.log();
        if(control.cid == "multiCodeCust"){
            parameter.isApplyDisplayFlag= true;
        }
        handler(parameter);
    },
    //중복되는 컨트롤 생성
    createContentsWidget(type,count,text){
        widgetList= [];
        var control = widget.generator.control();
        for(var i=0; i<count; i++){
            widgetList.push(control.define("widget."+type, 
                                            type+(i+1), 
                                            type+(i+1)+"name",
                                            text+(i+1)
                                            ).end());
        }
        return widgetList;
    },


    onInitFooter: function(footer){
        var control = widget.generator.control();
        var toolbar = widget.generator.toolbar().setId("footerToolbar");
    
        var save = control.define("widget.button","recovery").label("적용").end();
        //var reset = control.define("widget.button","reset").label("Reset").end();
        toolbar
                .attach(save)
                //.attach(reset);

        footer.add(toolbar);
    },
    onFooterRecovery: function () {
        //this.ecPageId : 나의 페이지 아이디
        //this.__ecPageId : 나를 부른 부모 페이지 아이디
        //this.popupLevel : 페이지 레벨 
        //this.reponseId : 부모페이지의 헨들러

        var data = {
            extract : this.contents.extract()
            // save : this.contents.save(),
            // serialize : this.contents.serialize(),
            //callback: this.callback.bind(this)
        }
        this.sendMessage(this, data);
        this.close();
    },
    consoleLog : function(obj){
        console.log(obj.contents.items[0].rows);
    },
    onChangeControl : function(control){
        if(control.cid == "chk1"){
            var cindex = control.cindex;
            var value = control.value;
            var currentValue = control.__self.getCheckedInfo().slice(1);

            if(cindex == 0){
                control.__self.setCheckedAll(value);
            }else{
                var diffValue = currentValue.all(function(info){
                    return info.checked;
                });
                control.__self.setValue(0, diffValue);
            }
        }

        switch(control.cid){
            case "input1": 
            if(control.value == "0"){
                var controlList = this.getControlList(this.contents);
                controlList.forEach(item=> {
                this.contents.getControl(item.id).setValue("");
        })
            } 
            break;
        }

    },

    onFooterSave(e){
        console.log("1234");
    },

    onFooterReset(e){
        var controlList = this.getControlList(this.contents);
        controlList.forEach(item=> {
           this.contents.getControl(item.id).setValue("");
        })
    },

    onLoadComplete: function(){
        this.header.toggleContents();
    }
});
