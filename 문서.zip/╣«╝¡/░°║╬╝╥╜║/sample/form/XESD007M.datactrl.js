
var testttt= window["viewBag" + __EC_PAGE_ID];
window["viewBag" + __EC_PAGE_ID].CacheInfo.form[0].formType = "SRTET";
window["viewBag" + __EC_PAGE_ID].CacheInfo.defaultForm = ["Z_SRTET_1"];
window["viewBag" + __EC_PAGE_ID].DefaultOption.outputFormType = "SRTET";
window["viewBag" + __EC_PAGE_ID].DefaultOption.searchFormType = "SNTET";
//window["viewBag" + __EC_PAGE_ID].DefaultOption.formSeqInfo = {"SRTET":1};
window["viewBag" + __EC_PAGE_ID].FormInfos.formOptionList.SRTET = window["viewBag" + __EC_PAGE_ID].FormInfos.formOptionList.SR030;
delete window["viewBag" + __EC_PAGE_ID].FormInfos.formOptionList.SR030;


