﻿/*********** *****************************************************************************************
1. Create Date : 2019.01.01
2. Creator     : XXX
3. Description : 판매조회(Sale Search)
4. Precaution  : 
5. History     : 
6. Old Files   : XESD007M.js
****************************************************************************************************/
ecount.page.factory("ecount.page.common", "ESD007M", {
    //init
    init: function (option) {
        this._super.init.apply(this, arguments);
    },

    //render
    render: function (option) {
        this._super.render.apply(this, arguments);
    },

    initProperties: function () {
        //columnMap 정의
        this.pageOption.columnMap = {
            //요청정보
            grid: {
                IO_DATE: "IO_DATE", IO_NO: "IO_NO", IO_TYPE: "IO_TYPE", F_FLAG: "F_FLAG", VERSION: "VERSION_NO", GB_TYPE: "GB_TYPE", WRITER_ID: "WRITER_ID",
				WID: "WID", IN_PART_WRITER: "IN_PART_WRITER", IN_PART: "IN_PART"
            }
        };

        //현재 페이지의 정보
        this.pageInfo = {
            title: ecount.resource.LBL35302,//타이틀
            permitMenuName: ecount.resource.LBL02935,//권한체크시 전표명칭
            name: "ESD007M",//페이지명			
            inputUrl: "/ECERP/SVC/ESD/ESD006M",//해당전표 입력 url
            path: this.isFromCS === true ? "/ECERP/SVC/CSA/ESD007M" : "/ECERP/SVC/ESD/ESD007M",//페이지 URL
            menuSeqInput: 492,//바코드인쇄메뉴 seq
            slipCd: "4130",//전표코드
            fromMenu: 1,//전표구분(1:Sales, 2:Purchase, 3:Goods Issued, 4:Goods Receipt, 5:Internal Use, 6:Product Defect, 7:lLocation Tran, 8:LRepair Order List, 9: Quality Insp. Request, 10:Quality Inspection)
            menuAuth: "SALE_CHK2",//메뉴구분
            docFlag: "66", // Email, Fax관련 DOC_TYPE
            formType: { output: "SRTET", print: "SFTET" },//인쇄양식
            type: "sale",				// 전표타입 //TODO 모두 제거 이후 삭제하겠습니다.

            pageHeader: [
                {
                    group: "header", id: "header",
                    child: [
                        { unit: "widget", type: "outputTitle" },//타이틀
                        { unit: "widget", type: "quickSearch" },//퀵서치
                        {
                            unit: "widget", type: "outputOption", id: "option",
                            settingInfo: { optionList: ["searchTemplate", "formListOption", "filterSetting", "automationSetting"] }
                        },//옵션버튼
                        {
                            group: "tabContents", type: "searchForm", id: "searchForm",
                            functions: ["userTab"],
                            settingInfo: {
                                isInitShowSearchTab: false,	//초기검색탭노출여부
                                isSerializeAllUse: false,	//체크박스 전체항목 데이터 포함여부 //TODO hhy 기본이 true일거 같은데 공통은 확인...
                            },
                        },
                        {
							group: "toolbar", id: "headerToolbar", sortType: "output-common-header", toolbarSearchType: "pageCustom",
                            child: [
                                { unit: "widget", type: "formList" },
                                { unit: "widget", type: "group", id: "searchGroup", sortType: "output-common-groupSearch", child: ["search", "userTabSaveSearch"] },
                                { unit: "widget", type: "simpleSearch" },
                                { unit: "widget", type: "rewrite" },

                            ],
                        },
                    ],
                },
            ],

            pageContents: [
                {
                    group: "outputContents", id: "contents",
                    functions: [
                        { function: "setOutputLayout" },//출력 레이아웃 설정
                    ],
                    child: [
                        //리스트탭
                        {
                            group: "tabContents", type: "listTab",
                            functions: [
                                { function: "listTabSearchParam", type: "inv" },//리스트탭 검색 파라미터(재고) 설정
                                { function: "loadListTabContents" },//리스트탭 컨텐츠 로드
                                { function: "listTabSyncForm" },//리스트탭 양식 동기화
                            ],
                        },

                        //그리드
                        {
                            group: "grid", type: "form", id: "gridForm",
                            settingInfo: {
                                keyColumn: ["IO_DATE", "IO_NO"],
                                renderType: "columnFix",
                                field: function () {
                                    var field = [
                                        { id: "CHK_H", key: "checkStatus" },
                                        { id: "STET_CS_CONFIRM.CS_CONFIRM_STATUS", key: "csConfirmStatus" },//주문서 전표 수정모드로 오픈
                                        { id: "SELL.s_print", key: "slipPrint", type: "inv" },// 전표인쇄(Print)  - 거래명세서 인쇄 
                                        { id: "sale003_img.prod_img", key: "image" },//이미지 링크
                                        { id: "SELL.io_date", key: "slip" },// 전표링크
                                        { id: "SELL.io_date_no", key: "slipNo" },//전표링크
                                        { id: "SELL.s_state", key: "invoicingStatus", type: "inv" },//회계반영여부  
                                        { id: "SELL.s_confirm", key: "confirmStatus" }//전표 확인/미확인 여부
                                    ];

                                    return field;
                                }.bind(this)(),
                            },
                            functions: [
                                { function: "gridSearch" },//그리드 검색
                                { function: "gridColumns" },//그리드 컬럼
                                { function: "gridCustomRowCell" },//그리드 customRowCell
                                { function: "gridDimension" },//그리드 dimension
                                { function: "gridPaging" },//그리드 페이징
                                { function: "nextSlip" },//다음전표
                                {
                                    function: "callSearchApi", type: "grid",//검색 데이터 조회
                                    settingInfo: {
                                        api: "/SVC/Common/SlipTransfer/GetListXFormSlipCommon",
                                    }
                                },
                                {
                                    function: "gridDescription",//그리드 설명
                                    settingInfo: {
                                        isBottomRight: false,//우측 하단 표시여부
                                    }
                                },
                                {
                                    function: "gridStyle",//그리드 스타일
                                    settingInfo: {
                                        isHeaderFix: true,//그리드 상단 틀고정 여부
                                        isColumnFixHeader: true,//컬럼헤더 틀고정 사용여부
                                    }
                                },
                                {
                                    function: "gridShade",//그리드 음영
                                    settingInfo: {
                                        hasGroupShaded: false,//그룹 음영여부
                                        shaded: ["SELL.io_date_no", "SELL.io_date", "SELL.s_print"],//음영컬럼
                                    }
                                },
                                {
                                    function: "gridCheckbox",//그리드 체크박스
                                },
                            ],
                        }
                    ],
                },
            ],

            pageFooter: [
                {
                    group: "footer", id: "footer",
                    child: [
                        {
                            group: "toolbar", id: "toolbarFooter", sortType: "output-common-footer",
                            functions: ["procNewSlip"],//신규 버튼  기능
                            child: [
                                {
                                    unit: "widget", type: "loadSlip",
                                    settingInfo: {
                                        getAddParam: function (param) {
                                            var addParam = {};
                                            switch (this.TO_TYPE) {
                                                case "659"://출하지시서
                                                    addParam = {
                                                        data: {
                                                            EditFlag: "Copy",
                                                            isQtyCheckFlag: "N",
                                                            ListYn: "N",
                                                            sale031Data: Object.toJSON(params.data.selectedKey),
                                                            screenSearchType: "2",
                                                            ParamDocNo: this.pageOption.docNo,
                                                        },
                                                    };
                                                    break;
                                                case "738"://품질검사입력
                                                    addParam = { data: { EditFlag: "CopySell" } };
                                                    break;
                                            }
                                            return addParam;
                                        },
                                    }
                                },
                                { unit: "widget", type: "share" },
                                { unit: "widget", type: "outputNew" },
                                { unit: "widget", type: "messenger" },
                                { unit: "widget", type: "applyRef" },
                                { unit: "widget", type: "slipDeleteSelected" },
                                { unit: "widget", type: "outputEmail" },
								{
                                    unit: "widget", type: "outputExcel",
									settingInfo: {
										label: ecount.resource.BTN00079, tabs: [""],
										pageSize: 0,
										getPathInfo: function (param) {
											return "/SVC/Inventory/Sale/ExcelSaleDetailByFormLastForSearch";
										},
										SheetName: "",
										SortColumns: "",
										ConvertRowDateColumns: "",
										QtyDataColNm: "",
									}
								},
                                { unit: "widget", type: "outputConfirm" },
                                { unit: "widget", type: "outputClose" },
                                { unit: "widget", type: "group", id: "printGroup", sortType: "output-common-groupPrint", child: ["print", "optimization"] },//인쇄 그룹 버튼
                                { unit: "widget", type: "group", id: "barcodeGroup", sortType: "output-common-groupBarcode", child: ["outputBarcode", "barcodeserial"] },//바코드 그룹 버튼
                                { unit: "widget", type: "orderMngApply" },
                                { unit: "widget", type: "orderMngExclude" },
                                { unit: "widget", type: "orderMngLoadApply" },
                                { unit: "widget", type: "moreData" },
                            ]
                        }
                    ]
                },
            ],

            pageFunction: [
                { function: "reloadPage" },//페이지 reload
                {
                    function: "printSlip", type: "inv",
                    settingInfo: {
                        paramPrint: function () {
                            return {
                                printUrl: "/ECERP/SVC/ESD/ESD007R",
                                formType: "SFTET"
                            }
                        },
                    }
                },//인쇄(재고)
                { function: "sendEmail" },//이메일 발송
                { function: "notiMessenger" },//메신저 알림
                {
                    function: "searchManager",//검색 Manager
                    settingInfo: {
                        isFirstLoadSearch: true,//처음 로딩시 검색여부
                        defaultSearchParam: {//기본 검색 파라미터
                            UQTY_FLAG: ecount.config.inventory.UQTY_FLAG,
                            P_FLAG: "A",
                            GB_TYPE: "N",
                            ALL_YN: "N",
                            COLID: "",
                            ORDER_FLAG: this.STETIsFromOrderMng ? "Y" : "N",
                            ORDER_PROC_NO: this.STETLinkType == "S" ? this.STETOrderProcNo : "",
                            ORDER_PROC_STEP: this.STETLinkType == "S" ? this.STETOrderProcStep : 0,
                            MENU_SEQ: 492,
                            CUST_CD: this.viewBag.CUST_CD
                        },
                    }
                },
                { function: "outputFormManager" },//출력양식 Manager
                {
                    function: "deleteManager", type: "inv",//삭제 Manager
                    settingInfo: {
                        path: "/SVC/Inventory/Sale/DeleteList",
                        isInvoiceDeleteUse: true,
                        filters: []
                    }
                },
                {
                    function: "confirmManager",//확인/확인취소
                    settingInfo: {
                        check: ["isInvoice", "isLimitDate", "isApproval"],
                        url: "/SVC/Inventory/Sale/ConfirmList",
                        // 확인 권한 confirm 가능 여부 [slip_auth_type] (재고전표확인권한타입) 4=일반, 5 = 확인권한)  [ecount.config.user.USE_SLIPAUTH_SALE] 판매 확인권한
                        isPermission: ecount.config.user.SLIP_AUTH_TYPE == "4" ? false : ecount.config.user.USE_SLIPAUTH_SALE
                    }
                },
                {
                    function: "slipLink",//전표링크
                    settingInfo: {
                        slip: function (rowItem, param) {//전표정보
                            return {
                                name: ecount.resource.LBL15145, //페이지 전표 타이틀
                                ProgramId: "E040205",
                                param: {
                                    Request: {
                                        Key: {
                                            Date: rowItem.IO_DATE,
                                            No: rowItem.IO_NO
                                        },
                                        EditMode: ecenum.editMode.modify,
                                        FromProgramId: "E040207",
                                        PrevUrl: this.pageInfo.path,
                                        UIOption: {
                                            Width: 920,
                                            Height: 800,
                                            FocusRowNumber: rowItem.SER_NO || 1,
                                        }
                                    }
                                }
                            }
                        }.bind(this),
                    }
                }
            ],
        };
    },
});