1. Action : MVC에서 Model이랑 상등

2. Mock이 필요한 경우 : 서버 개발이 안됐지만 화면 개발을 해야 할 경우

3. Mock 환경 개발 할 때 필요한 3개 파일 (MockDefaultAction.cs, 개발해야되는 js파일, mock.config.js)

4. formType : 메뉴별 양식 타입

5. formSeq : 같은 formType에서 몇번째인지 보여주는 값

6. resource : 언어관련 값