ecount.page.factory("ecount.page", "ESD006M", {
    /********************************************************************** 
    *   Init Data Setting function
    **********************************************************************/
    //page init event
    init: function (options) {
        this._super.init.apply(this, arguments);
    },

    //page render event
    render: function () {
        this._super.render.apply(this);
    } ,
   
//header
    onInitHeader: function(header){
        var g = widget.generator,
        contents = g.contents(),
        control = g.control();
        var btn = control.define("widget.button","search","btn1")
                        .label("Search");

        header.setTitle("NewCount");
        header.add(btn);
    },

//contents
    onInitContents: function(contents){
        var g = widget.generator,
        form = g.form()
        control = g.control(),
        grid1 = g.grid(),
        grid2 = g.grid();


        var rowData = [];
        var mergeData = {};

        mergeData['_ROW_TITLE'] = "merge";
        mergeData['_COLSPAN_COUNT'] = 2;
        mergeData['_MERGE_START_INDEX'] = 1;
        mergeData['_IS_BOLD'] = true;
        mergeData['_IS_CENTER_ALIGN'] = true;

        for(var i=0; i<10; i++){
            rowData.push({
            "A0": (i<9 ? "2020/03/0"+(i+1)+("-"+(i+1)) : "2020/03/"+(i+1)+("-"+(i+1))),
            "A1": "이카운트"+(i+1),
            "A2": "모니터"+(i+1),
            "A3": 10.00000,
            //"A4": '',
            "MAXCNT" : 100,
            "_MERGE_SET": []
            })
        }
        rowData[1]['_MERGE_SET'] = [mergeData];
        grid1.setColumns([
            {
                id: "data_no",
                title : "전표일자",
                width : 200,
                controlType:'widget.link',
                dataType: '22'
            },
            {
                id: "cust_des",
                title : "거래처명",
                width : 200,
                controlType:'widget.label',
                fontBold: 1
            },
            {
                id: "prod_des",
                title : "품목명",
                width : 200,
                controlType:'widget.label',
            },
            {
                id: "tot_amt",
                title : "금액합계",
                width : 200,
                controlType:'widget.label',
                dataType : '92'
            },
            {
                id: "s_state",
                title : "회계반영여부",
                width : 200,
                controlType:'widget.faCheckLink',
                align : "center"
            },
            {
                id: "A7",
                title : "print",
                width : 200,
                controlType:'widget.link',
                align : "center"
            },

        ])
        .setRowData(rowData)
        //.setColumnPropertyColumnName('id')
        .setKeyColumn(['data_no','cust_des'])
        //paging
        .setRowDataUrl('/Account/Basic/GetSiteList')
        .setPagingUse(true)
        .setPagingRowCountPerPage(10,true)
        .setPagingUseDefaultPageIndexChanging(true)
        //
        .setCheckBoxUse(true)
        .setCheckBoxMaxCount(3)
        .setCheckBoxMaxCountExceeded(function () {
                ecount.alert("@@@@");
            }
          )
        .setRowDataSample({"A5":"인쇄"})
          //음영처리
        .setEventShadedColumnId('data_no')
        .setCustomRowCell('data_no',function(value,rowItem){
            var obj = {};
            obj.event ={
                'click' : function(e, data){
                    ecount.alert(data.rowItem[ecount.grid.constValue.keyColumnPropertyName]);
                }
            }
            
            return obj;
        })
        .setCustomRowCell('prod_des',function(value,rowItem){
            var obj = {};
            if(rowItem[ecount.grid.constValue.keyColumnPropertyName] == "2020/03/01-1∮이카운트1"){
                obj.attrs = {};
                obj.attrs.class = 'text-italic';
            }
            return obj;
        })
        .setCustomRowCell('s_state',function(value,rowItem){
            var obj = {};
            if(rowItem[ecount.grid.constValue.keyColumnPropertyName] == "2020/03/01-1∮이카운트1"){
                obj.parentAttrs = {};
                obj.parentAttrs.class = 'text-right';
                obj.attrs = {};
                obj.attrs.class = 'text-warning';
            }
            return obj;
        })
        .setCustomRowCell('cust_des',function(value,rowItem){
            var obj = {};
            if(rowItem[ecount.grid.constValue.keyColumnPropertyName] == "2020/03/01-1∮이카운트1"){
                obj.data = '이카운트11';
            }
            return obj;
        })
        .setHeaderTopRightHTML(Date.now());
        //.setMergeData(mergeData);

        //입력 그리드
        grid2.setColumns([
            {
                id: "prod_cd",
                title : "품목코드",
                width : 100 ,
                controlType:'widget.code.prod',
            },
            {
                id: "prod_des",
                title : "품목명",
                width : 100,
                controlType:'widget.input.general',
                fontBold: 1
            },
            {
                id: "qty",
                title : "수량",
                width : 100,
                controlType:'widget.input.number',
                align : "center",
                controlOption : {
                    decimalUnit : [18,6],
                },
                dataType:'96' //화면에 보이는 값만 변경, 데이터는 변경 안함
            },
            {
                id: "price",
                title : "단가",
                width : 100,
                controlType:'widget.input.number',
                align : "center",
                //linechange : true
            },
            {
                id: "supply_amt",
                title : "공급가액",
                width : 100,
                controlType:'widget.input.number',
                align : "center"
            },
            {
                id: "vat_amt",
                title : "부가세",
                width : 100,
                controlType:'widget.input.number',
                align : "center"
            },
            {
                id: "inspection",
                title : "검사",
                width : 100,
                controlType:'widget.select'
            },
            {
                id: "size_des",
                title : "규격선택",
                width : 80,
                controlType:'widget.input.general',
                isHideColumn : true //true이면 안보임
            }
        ])
        .setRowData([])
        .setEditable(true,3,3)
        .setCheckBoxUse(true)
        .setEditRowMoveable(true)
        .setEditSpecialRowCount(1)
        .setColumnsAutoSetting({
            'qty' : {'actionType' : 'sum','total':0},
            'price' : {'actionType' : 'sum','total':0},
            'supply_amt' : {'actionType' : 'sum','total':0},
            'vat_amt' : {'actionType' : 'sum','total':0},
        })
        .setEventAutoAddRowOnLastRow(true,2)
        .setCustomRowCell('prod_cd',function(value,rowItem){
            var option = {};
            
            option.controlOption = {
                controlEvent: {
                    'itemSelect' : function(rowKey, arg, control){
                        var grid = this.contents.getGrid("grid2").grid;
                        var rowItem = arg.rowItem;
                        grid.setCell('prod_cd',rowKey,rowItem.PROD_CD);
                        grid.setCell('prod_des',rowKey,rowItem.PROD_DES);
                        grid.setCell('price',rowKey,100*(parseInt(rowKey)+1));
                        grid.setCell('supply_amt',rowKey,100*(parseInt(rowKey)+1));

                        grid.setCellFocus('qty',rowKey);
                    }.bind(this)
                }
            }

            return option;
        }.bind(this))
        .setCustomRowCell('supply_amt',function(value,rowItem){
            var option = {};
            option.event = {
                'change' : function(e, data){
                    var vatAmt = data.newValue * 0.1;
                    var rowKey = data.rowKey;
                    var grid = this.contents.getGrid("grid2").grid;
                    grid.setCell('vat_amt',rowKey,vatAmt);
                }.bind(this)
            }

            return option;
        }.bind(this))
        .setCustomRowCell('inspection',function(value,rowItem){
            var option = {};
            var selectOption = [];
            selectOption.push(["0","선택"]);
            selectOption.push(["1","숨기기"]);
            selectOption.push(["2","보이기"]);

            option.optionData = selectOption;

            option.event={
                'change' : function(e, data){
                    var grid = this.contents.getGrid("grid2").grid;
                    if(data.newValue == "1"){
                        grid.setColumnVisibility('size_des',false); //cloumnId와 true or false를 넣으면 columnId값을 가진 컬럼이 hied or show
                    }else if(data.newValue  == "2"){
                        grid.setColumnVisibility('size_des',true);
                    }
                }.bind(this)
            }

            return option;
        }.bind(this))
        .setCustomRowCell('qty',function(value,rowItem){
            var option = {};
            option.event={
                'focus' : function(e, data){
                   
                   var grid = this.contents.getGrid("grid2").grid;
                   var key = data.rowKey;
                   var nowIndex = grid.getRowIndexByKey(key);
                   
                   if(nowIndex != 0){
                    var beforeRowKey = grid.getRowKeyByIndex(nowIndex-1);
                    var beforeRowValue = grid.getCell('qty',beforeRowKey);
                    var rowItem = grid.getRowItem(beforeRowKey);
                    
                    if(beforeRowValue !== ""){
                        grid.setCell('qty',nowIndex,beforeRowValue);
                        grid.addChecked(key);
                    }
                    this.console(rowItem);  
                   }
                }.bind(this)
            }
            return option;
        }.bind(this))
        //addGrid("id",세팅한 객체)
        contents.addGrid("grid1",grid1);
        contents.addGrid("grid2",grid2);
    },

   
//footer
    onInitFooter: function(footer){
        var g = widget.generator,
        control = g.control(),
        toolbar = g.toolbar();
        toolbar.addLeft(control.define("widget.button","delete","removRow")
                               .label("RemovRow")
                               .end())
                .addLeft(control.define("widget.button","up","up")
                               .label("up")
                               .end())
                .addLeft(control.define("widget.button","down","down")
                               .label("down")
                               .end())
                .addLeft(control.define("widget.button","validate","validate")
                               .label("validate")
                               .end())
                .end();
        footer.add(toolbar);


    },

//function
    onHeaderSearch : function(){
        this.openWindow({
            url : "/ECERP/SVC/ESD/ESD007M"
        })
    },
    onFooterSave : function(){
       console.log(this.contents.extract());
    },
    onFooterDelete : function(){
        var grid = this.contents.getGrid('grid2').grid;
        var checkedList = grid.getChecked();
        
        checkedList.forEach(function(item){
            var keyChange = item['K-E-Y'];
            grid.removeRow(keyChange);
        })
        
        console.log(checkedList);

    },
    onFooterUp : function(){
        var grid = this.contents.getGrid('grid2').grid;
        grid.moveUpChecked();
    },
    onFooterDown : function(){
        var grid = this.contents.getGrid('grid2').grid;
        grid.moveDownChecked();
    },
        onFooterValidate : function(){
        var grid = this.contents.getGrid('grid2').grid;
        var rowItem = grid.getRowItem(0);
        var ColumnIdList = ["PROD_CD",'PROD_DES','QTY'];
        var option = {placement: "auto",
                      message: "자료를 입력 바랍니다.",
                      popOverVisible: true};
        var rowCount = grid.getRowCount();
        
        var rowList = grid.getRowList();
        this.console(rowList);
        for(var i=0; i<  ColumnIdList.length; i++){
            for(var j=0; j< rowList.length; j++){
                this.console(rowList[j][ColumnIdList[i]]);
            }
        }
        // for(){
            
        // }







        // for(var i=0; i<1; i++){
        //     var checkCnt = 0;
        //     for(var j=0; j<ColumnIdList.length; j++ ){
        //         var checkData = grid.getCell(ColumnIdList[j],i);
        //         if(checkData == ""){
        //             grid.setCellShowError(ColumnIdList[j],i,option);
        //             checkCnt++;
        //         }
        //     }
        //     if(checkCnt == 0){
        //         ecount.alert("저장되었습다!");
        //     }
        // }
        // for(var i=0; i<ColumnIdList.length; i++){
        //     for(var j=0; j<rowList.length; j++){
        //         var key = rowList[j]["K-E-Y"];
        //         var data = grid.getCell(ColumnIdList[i],key);
        //         this.console(key+"%%%%%"+data);
        //     }
            
        // }
    },
    onChangeControl : function(control){
        if(control.cid == "check1"){
            var cindex = control.cindex;
            if(cindex == 0 && control.value){
                this.contents.getControl("input1").hide();
            }else if(cindex == 0 && !control.value){
                this.contents.getControl("input1").show();
            }
        }
    },
    onLoadComplete: function(){

    },
    onInitControl : function(cid, control){
        if(cid == "input2"){
            control.readOnly();
        }
    },
    onGridAfterRowDataLoad : function(e,data){
        var mergeData = {};
        mergeData['_ROW_TITLE'] = "merge";
        mergeData['_COLSPAN_COUNT'] = 2;
        mergeData['_MERGE_START_INDEX'] = 1;
        mergeData['_IS_BOLD'] = true;
        mergeData['_IS_CENTER_ALIGN'] = true;
        mergeData['_ROWSAPN_COUNT'] = 2;

        data.result.Data.forEach(function(data){
            data._MERGE_SET = [];
        });
        data.result.Data[4]['_MERGE_SET'] = [mergeData];
    },
    onGridRenderComplete: function(e,data, gridObj){
        ecount.page.list.prototype.onGridRenderComplete.apply(this,arguments);//이게 있어야 정상 작동
        var grid3 = this.contents.getGrid("grid1").grid;
        //  grid1.addCellClass()
    },
    console : function(obj){
        console.log("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
        console.log(obj);
        console.log("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
    }
});