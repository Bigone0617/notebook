/****************************************************************************************************
1. Create Date : 2018.08.01
2. Creator     : 류상민
3. Description : 견적서조회(Quotation Search)
4. Precaution  : 
5. History     : 2019.12.11 (이철원) - 조회-현황 공통 적용
6. Old Files   : ESD002M.js
****************************************************************************************************/
ecount.page.factory("ecount.page.common", "ESD002M", {
    //init function
    init: function (option) {
        this._super.init.apply(this, arguments);
        debugger;
    },

    //render
    render: function (option) {
        this._super.render.apply(this, arguments);
    },

    initProperties: function () {
        this.pageOption.columnMap = {
            grid: {
                IO_DATE: "IO_DATE", IO_NO: "IO_NO",
            },
        }
        
        this.pageInfo = {
            
           title:"TodoList",	// 타이틀
            //permitMenuName: ecount.resource.LBL93311,
            //name: "ESD002M",
            //inputUrl: "/ECERP/SVC/ESD/ESD001M",//해당전표 입력 url
            //path: this.isFromCS === true ? "/ECERP/SVC/CSA/ESD002M" : "/ECERP/SVC/ESD/ESD002M",     // 페이지 URL
            //slipCd: "4110",
            //fromMenu: 1,//전표구분(1:Sales, 2:Purchase, 3:Goods Issued, 4:Goods Receipt, 5:Internal Use, 6:Product Defect, 7:lLocation Tran, 8:LRepair Order List, 9: Quality Insp. Request, 10:Quality Inspection)
            //menuAuth: "SALE_CHK2",
            //docFlag: "22",
            //formType: {
            //    search: this.isFromCS ? "ON010" : "SN010",
            //    output: this.isFromCS ? "OR010" : "SR010",
            //    print: "SF010"
            //},
            //type: "quotation",                                                              // 전표타입
            //state: false,
            

            pageHeader: [
                {
                    group: "header", id: "header",
                    child: [
                        {
                            unit: "widget", type:"outputTitle"
                        },
                        { unit: "widget", type: "quickSearch" },
                        {
                            group: "tabContents", type: "searchForm", id: "searchForm",
                            functions: ["userTab"],
                            settingInfo: {
                                isInitShowSearchTab: false,
                                isSerializeAllUse: false
                            },
                            child: [
                                {
                                    unit: "widget", type: "customizer", id: "EtcChk",
                                    child: [
                                        { unit: "widget", type: "sortModifiedDate" },//수정일자순(정렬)
                                    ]
                                },
                            ]
                        },
                        {
                            group: "toolbar", id: "headerToolbar", sortType: "output-common-header", toolbarSearchType: "pageCustom",
                            child: [
                                { unit: "widget", type: "formList" },
                                { unit: "widget", type: "group", id: "searchGroup", sortType: "output-common-groupSearch", child: ["search", "userTabSaveSearch"] },
                                { unit: "widget", type: "simpleSearch" },
                                { unit: "widget", type: "rewrite" }
                            ]
                        }
                    ]
                }
            ],
            pageContents: [
                {
                    group: "contents", id: "contents", type: "output",
                    functions: [
                        { function: "setOutputLayout" }
                    ],
                    child: [
                        //{
                        //    group: "tabContents", type: "listTab",
                        //    functions: [
                        //    ]
                        //},
                        //그리드
                        {
                            group: "grid", type: "form", id: "gridForm-ESD002M",
                            settingInfo: {
                                keyColumn: ["EST_DATE", "EST_NO"],
                                renderType: "columnFix",
                            },
                            child: [
                            ],
                            functions: [
                            ],
                        }
                    ]
                }
            ],
            pageFooter: [
                {
                    group: "footer", id: "footer",
                    child: [
                        {
                            group: "toolbar", id: "toolbarFooter", sortType: "output-common-footer",
                            functions: ["procNewSlip"],
                            child: [
                                {
                                    unit: "widget", type: "outputTaeil"
                                },
                                {
                                    unit: "widget", type: "outputSave"
                                },
                                {
                                    unit: "widget", type: "outputDelete"
                                },
                               
                            ]
                        }
                    ]
                }
            ],
            pageFunction: [
                { function: "reloadPage" },
                { function: "outputFormManager" },
                {
                    function: "searchManager",
                    settingInfo: {
                        isFirstLoadSearch: true,
                        defaultSearchParam: {
                            P_FLAG: "0",
                            GB_TYPE: "Y",
                            ALL_YN: "N",
                            WriteDateColNm: "SALE020.WRITE_DT",
                            EditDateColNm: "SALE020.UPDATE_DATE",
                            ORDER_FLAG: this.STETIsFromOrderMng ? "Y" : "N",
                            ORDER_PROC_NO: this.STETLinkType == "S" ? this.STETOrderProcNo : "",
                            ORDER_PROC_STEP: this.STETLinkType == "S" ? this.STETOrderProcStep : 0,
                            MENU_SEQ: 487,
                            IsChangeDateFormat: true,
                            CUST: this.CUST,
                            CUST_DES: this.CUST_DES
                        }
                    }
                },
            ]
        }

    },
    onInitGroupGridForm: function () {
        var customOption = {
            isOverriding: true,
            createLayout: function (contents) {
                var g = widget.generator,
                    inputGrid = g.grid(),
                    ViewGrid = g.grid();
                
                //입력 그리드
                inputGrid.setColumns([
                    {
                        id: "todo_type",
                        title: "타입",
                        width: 80,
                        controlType: 'widget.select',
                    },
                    {
                        id: "enrollment_date",
                        title: "등록일자",
                        width: 200,
                        controlType: 'widget.date',
                        fontBold: 1
                    },
                    {
                        id: "todo_work",
                        title: "할일",
                        width: 400,
                        controlType: 'widget.input.general',
                    },
                    {
                        id: "success_check",
                        title: "완료여부",
                        width: 100,
                        controlType: 'widget.select',
                    },
                    {
                        id: "success_date",
                        title: "완료일자",
                        width: 200,
                        controlType: 'widget.date',
                    },
                ])
                    .setRowData([])
                    .setCheckBoxUse(true)
                    .setEditable(true, 1, 0)
                    .setCustomRowCell('todo_type', function (value, rowItem) {
                        var option = {};
                        var selectOption = [];
                        selectOption.push(["0", "선택"]);
                        selectOption.push(["1", "work"]);
                        selectOption.push(["2", "personal"]);
                        option.optionData = selectOption;
                        return option;
                    }.bind(this))
                    .setCustomRowCell('success_check', function (value, rowItem) {
                        var option = {};
                        var selectOption = [];
                        selectOption.push(["0", "진행중"]);
                        selectOption.push(["1", "완료"]);
                        option.optionData = selectOption;
                        return option;
                    }.bind(this))

                //조회 그리드
                //ViewGrid.setColumns([
                //    {
                //        id: "todo_type",
                //        title: "타입",
                //        width: 80,
                //        controlType: 'widget.label',
                //    },
                //    {
                //        id: "enrollment_date",
                //        title: "등록일자",
                //        width: 200,
                //        controlType: 'widget.label',
                //        fontBold: 1
                //    },
                //    {
                //        id: "todo_work",
                //        title: "할일",
                //        width: 400,
                //        controlType: 'widget.label',
                //    },
                //    {
                //        id: "success_check",
                //        title: "완료여부",
                //        width: 100,
                //        controlType: 'widget.label',
                //    },
                //    {
                //        id: "success_date",
                //        title: "완료일자",
                //        width: 200,
                //        controlType: 'widget.label',
                //    },
                //])
                //    .setRowData([])
                //    .setCheckBoxUse(true)

                //if (this.pageOption.state) {
                //    return ViewGrid;
                //} else {
                //    return inputGrid;
                //}
                return inputGrid;
                
            }
        }
        return customOption;
    }
    //, onInitGrouptoolbarFooter: function () {
    //    var customOption = {
    //        isOverriding: true,
    //        createLayout: function (contents) {
    //            var g = widget.generator,
    //                control = g.control(),
    //                NewBtn = control.define("widget")
    //        }
    //    }
    //    return customOption;
    //}
});