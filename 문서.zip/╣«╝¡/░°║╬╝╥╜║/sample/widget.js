/****************************************************************************************************
1. Create Date : 2018-04-03
2. Creator     : 허휘영
3. Description : 판매입력(Sale)
4. Precaution  :                
5. History     : 2018.09.18 (TanThanh) - Change function Copy to footer Copy button
                 2019.01.09 (HoangLinh): A18_04370_1 - Refactoring
                 2019.01.29 (PhiVo) A19_00340 - FE 리팩토링_페이지 일괄작업 5차 - apply method getFnItemById and not use method getFnItem in method save
                 2019.06.10 (AiTuan) - A18_01169 - 참조 공통화(판매입력)
                 2019.07.18 (AiTuan) - Set refTabId = this.tabIdList.main
                 2019.08.26 (허휘영) - 입력공통 리팩토링 단위 기능분리
                 2019.09.17 [LuongAnhDuy] A19_02831 -  재고 > 확인 권한이 있어도 미확인 전표수정시 미확인상태로 유지
6. MenuPath    : 재고1>영업관리>판매>판매입력
7. Old File    : View.ESD/XESD006M.js 
9. Etc         :  
****************************************************************************************************/
ecount.page.factory("ecount.page", "ESD006M", {
    /********************************************************************** 
    *   Init Data Setting function
    **********************************************************************/
    //page init event
    init: function (options) {
        this._super.init.apply(this, arguments);
    },

    //page render event
    render: function () {
        this._super.render.apply(this);
    } ,
    //contents에 있는 컨트롤 받아오기
    getControlList : function(contents){
        controlList = [];
        if(contents.items[0]){
            contents.items[0].rows.forEach(item => {
                controlList.push(item);
            })
        }
        return controlList;
    },

    onInitHeader: function(header){
        header.setTitle("NewCount");

        var control = widget.generator.control();
       
        var button = control.define("widget.button","search","button1").label("Search");

        //tab
        var tabContents = widget.generator.tabContents();
        var contents = widget.generator.contents();

        tabContents
                .setFormInfo(this.viewBag.FormInfos.formSearch)
        //this.viewBag.FormInfos.formSearch : 양식 정보
        

        contents.add(tabContents);
        header.add(button);
        header.addContents(contents);
    },

    onHeaderSearch : function(){
        console.log(this.ecPageID);
        debugger;
        this.openWindow({
            url : "/ECERP/SVC/ESD/ESD007M",
            param: {
                __ecPageID : this.ecPageID
            }
        })
    },

    onInitControl : function(cid, control){
        if(cid=="txtDocNo"){
            control.readOnly();
        }else if(cid=="ddlSTaxFlag"){
            control.label(["전체","미청구","미확인"])
                   .value(["all","1","2"]);
        }else if(cid=="ddlForeignFlag"){
            control.label(["전체","미청구","미확인"])
                   .value(["all","1","2"]);
        }
    },

    onInitContents: function(contents){
        var form = widget.generator.form();
        var inputList = this.createContentsWidget("input",4,"거래처");

        // subcontrol을 만든 이유는 기존에 있던 control에 덮어쓰지 않기 위해서
        var subControl = widget.generator.control(); 
        var control = widget.generator.control();

        
        
        form.add(control
                .define("widget.checkbox","chk1","CHK_NAME","선택항목")
                .label(["전체","본문","답글"])
                .value(["all","1","0"])
                .end()
            )



        form.add(control
                .define("widget.combine.specName","combine","combine","combine")
                .end())


        form.add(control
                .define("widget.customizer.specName2","customizer","customizer","customizer")
                .addControl(subControl.define("widget.input","subinput","subinput","subinput")
                            .end())
                .addControl(subControl.define("widget.button","subinput2","subinput2","subinput2")
                            .hide()
                            .end())
                .addControl(subControl.define("widget.input","subinput3","subinput3","subinput3")
                            .hide()
                            .end())
                .addControl(subControl.define("widget.radio","subradio")
                            .label(["input1","input2","input3"])
                            .value(["1","2","3"])
                            .end())
                .end())


        






        form.add(control
                .define("widget.radio","chk2","CHK_NAME","선택항목")
                .label(["전체","본문","답글"])
                .value(["all","1","0"])
                //fn생성
                .hasFn([
                    {label: "test1", id : "fntest"}
                ])
                .end())

        form.add(control
                .define("widget.select","chk3","CHK_NAME","선택항목")
                .option([["all","전체"],["1","본문"],["0","답글"]])
                .end())

        form.add(control
                .define("widget.code.cust","cust","CHK_NAME","선택항목")
                .end())

        form.add(control
                .define("widget.multiCode.cust","multiCodeCust","cust_NAME","거래처")
                .end())

        form.add(control
                .define("widget.multiCode.prod","multiCodeProd","prod_NAME","품목")
                .end())

        form.add(control
                .define("widget.multiCode.wh","multiCodeWh","wh_NAME","창고")
                .end())

        form.setFormId("ecountContentsForm")
            .add(inputList[0])
            .add(inputList[1])
            .add(inputList[2])
            .add(inputList[3]);

        contents.add(form);
    },

    //fnFunction
    onFunctionFntest : function(){
        alert(111);
    },


    onMessageHandler: function (context, data) {
        //debugger;
        //형태 자체를 바꿈
       // console.log(data.extract.result);
       //this.header.lastReset(data.extract.result);

       //값만 바꿈
       //this.contents.resote(data.save);


       //submit
       if(context.pageID == "EBA068M"){
           this.onSubmit("/ECERP/SVC/ESD/ESD006M");
       }
    },
    onPopupHandler: function(control, parameter, handler){
        //isApplyDisplayFlag
        if(control.cid == "multiCodeCust"){
            parameter.isApplyDisplayFlag= true;
        }
        handler(parameter);
    },
    //중복되는 컨트롤 생성
    createContentsWidget(type,count,text){
        widgetList= [];
        var control = widget.generator.control();
        for(var i=0; i<count; i++){
            widgetList.push(control.define("widget."+type, 
                                            type+(i+1), 
                                            type+(i+1)+"name",
                                            text+(i+1)
                                            ).end());
        }
        return widgetList;
    },


    onInitFooter: function(footer){
        var control = widget.generator.control();
        var toolbar = widget.generator.toolbar().setId("footerToolbar");
    
        var save = control.define("widget.button","save").label("Save").end();
        var reset = control.define("widget.button","reset").label("Reset").end();
        //버튼 그룹
        var addGroup = control.define("widget.button.group","groupId","groupName")
                                .label("Group")
                                .addGroup([
                                    {label: "group1", id : "group1"},
                                    {label: "group2", id : "group2"}
                                ])
                                .end();

        toolbar
                .attach(save)
                .attach(reset)
                .attach(addGroup);

        footer.add(toolbar);
    },

    onButtonGroup1: function(){
        alert(1);
    },

    // onChangeControl : function(control){
    //     if(control.cid == "chk1"){
    //         var cindex = control.cindex;
    //         var value = control.value;
    //         debugger;
    //         var currentValue = control.__self.getCheckedInfo().slice(1);

    //         if(cindex == 0){
    //             control.__self.setCheckedAll(value);
    //         }else{
    //             var diffValue = currentValue.all(function(info){
    //                 return info.checked;
    //             });
    //             control.__self.setValue(0, diffValue);
    //         }
    //     }

    //     switch(control.cid){
    //         case "input1": 
    //         if(control.value == "0"){
    //             var controlList = this.getControlList(this.contents);
    //             controlList.forEach(item=> {
    //             this.contents.getControl(item.id).setValue("");
    //     })
    //         } 
    //         break;
    //     }

    // },

    onChangeControl: function(event){
        if(event.cid == "subradio"){
            if(event.value == "1"){
                this.contents.getControl("subinput").show();
                this.contents.getControl("subinput2").hide();
            }else if(event.value == "2"){
                this.contents.getControl("subinput2").show();
                this.contents.getControl("subinput").hide();
            }else if(event.__self.pcid){
                this.contents.getControl(event.__self.pcid).get(1).hide();
                this.contents.getControl(event.__self.pcid).get(0).show();
            }
        }
    },

    onFooterSave(e){
        console.log("1234");
    },

    onFooterReset(e){
        var controlList = this.getControlList(this.contents);
        controlList.forEach(item=> {
           this.contents.getControl(item.id).setValue("");
        })
    },

    onLoadComplete: function(){
        this.header.toggleContents();
        var txtBondDebitNo = this.header.getControl("txtBondDebitNo");
        txtBondDebitNo.setValue("1111");
    }
});
