var viewBag = window["viewBag" + __EC_PAGE_ID];
//신규화면
viewBag.DefaultOption = _.merge({}, viewBag.DefaultOption, { outputFormType: "TR001", formSeqInfo: { TR001: 1 } });


viewBag.DefaultOption.UIOption = {};



