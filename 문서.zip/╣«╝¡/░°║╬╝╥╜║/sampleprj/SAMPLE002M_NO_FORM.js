/***********************************************************************************
1. Create Date : yyyy.mm.dd
2. Creator     : Hong gil dong
3. Description : sample list
4. Precaution  :
5. History     : 
6. MenuPath    : 
7. Old File    :
9. Etc         :
***********************************************************************************/
ecount.page.factory("ecount.page.common", "SAMPLE002M", {
    init: function () {
        this._super.init.apply(this, arguments);
        
        //this.pageOption.EditMode = ecount.page.list.prototype.editMode;
        this.pageOption.EditMode = viewBag.DefaultOption.EditMode;
        
        this.pageInfo.modifyTitle = "Sample Update";
        this.pageInfo.inputTitle = "Sample Input";
        
       if(this.pageOption.EditMode == "01"){
            this.pageOption.readOnly = false;
       }else if(this.pageOption.EditMode == "02"){
            this.pageOption.readOnly = true;
       }
    },

    render: function () {
        this._super.render.apply(this, arguments);
        
    },

    initProperties: function () {
       
        this.pageOption.columnMap = {
            widget: {
                code: {id: "code", class: "code", isKey:true},
                code_name: {id: "code_name", class: "codeName"},
                remarks: {id: "remarks", class: "remarks"},
            }
        }
        this.pageInfo = {
            title: "",
            FORM_TYPE_GRID: "TI001",
            pageHeader: [
                
                {
                    group: "header", id: "header",
                    settingInfo: {
                        bookmark: false
                    },
                    child: [
                        { unit: "widget", type: "inputTitle" },
                    ]
                }
            ],
            pageContents: [
                {
                    group: "contents", type: "output", id: "contents",
                    child: [
                        {
                            group: "form",type:"inv", id: "form",
                            settingInfo: {
                               
                            },
                            child: [
                            ]
                        }
                    ]
                }
            ],
            pageFooter: [
                {
                    group: "footer", id: "footer",
                    child: [
                        {
                            group: "toolbar", id: "toolbarFooter", sortType: "output-common-footer",
                            child: [
                                { unit: "widget", type: "save" },
                                { unit: "widget", type: "remove" },
                                { unit: "widget", type: "notUse" },
                                { unit: "widget", type: "close" },
                                { unit: "widget", type: "test" },
                            ]
                        }
                    ]
                },
            ],
            pageFunction: [
              
            ]
        }
    },

    // 캐시 바라보지 않게끔 재정의
    onInitFunctionOutputFormManager: function () {
        return {
            isOverriding: true,
            init: function () {
                eccomposite_v1.function.prototype.init.apply(this, arguments);

                //form type
                this._formType = this.pageOption.outputFormType;

                //form seq
                this._formSeq = 1

                //다음 검색 form type
                this._nextSearchFormType = this._formType;

                //출력 양식 (일단 단일 양식으로)
                this._outputForm = this.viewBag.FormInfos[this._formType];
            }
        }
    },

    //저장 버튼
    onInitUnitWidgetSave: function () {
        return {
            init: function () {
                eccomposite_v1.unit.widget.prototype.init.apply(this, arguments);
            },
            
            render: function (parent) {
                eccomposite_v1.unit.widget.prototype.render.apply(this, arguments);
                this.createLayout(parent);
            },

            createLayout: function (parent) {
                var ctrl = widget.generator.control();

                parent.addLeft(ctrl.define("widget.button", this.id, '')
                        .label(ecount.resource.BTN00065))

                //단축키 등록
                this.saveShortCutKey("F8");

                //이벤트 바인딩
                this.createButtonEvent();
            },

            _ON_CLICK: function (e) {
                var validation = this.getLayout("contents").validate();
                if(validation.result.length > 0) {
                    validation.result[0][0].control.setFocus(0);//setfocus는 cindex이다
                    return;
                }
                //this.consoleTi(this.contents.items[0].rows);
                //this.consoleTi(this.getControls("code_name"));
                var param = this.getLayout("contents").items[0].rows;
                
                ecount.common.api({
                    url: "/ECAPI/SVC/Basic/Sample/SaveSampleData",
                    data: param,
                    success: function(result){
                        if(result.Status == "200"){
                            this.sendMessage({callback: this.close.bind(this)});
                        }else{
                            return false;
                        }
                    }.bind(this),
                    error: function(result){
                        console.log(result);
                    }
                });
            }
            
        }
    },

    //닫기 버튼
    onInitUnitWidgetClose: function () {
        return {
            init: function () {
                eccomposite_v1.unit.widget.prototype.init.apply(this, arguments);
            },
            
            render: function (parent) {
                eccomposite_v1.unit.widget.prototype.render.apply(this, arguments);
                this.createLayout(parent);

                //이벤트 바인딩	
                this.createButtonEvent();
            },

            createLayout: function (parent) {
                var ctrl = widget.generator.control();
               
                    parent.addLeft(ctrl.define("widget.button", this.id, '')   
                    .label(ecount.resource.BTN00008))
            },
            _ON_CLICK: function (e) {
                this.close();
            }

        }
    },

    //삭제 버튼 
    onInitUnitWidgetRemove: function () {
        return {
            init: function () {
                eccomposite_v1.unit.widget.prototype.init.apply(this, arguments);
            },
            
            render: function (parent) {
                eccomposite_v1.unit.widget.prototype.render.apply(this, arguments);
                this.createLayout(parent);

                //이벤트 바인딩	
                this.createButtonEvent();
            },

            createLayout: function (parent) {
                var ctrl = widget.generator.control();
               if(this.pageOption.EditMode && this.pageOption.EditMode === "02"){
                    parent.addLeft(ctrl.define("widget.button", this.id, '')
                        .label(ecount.resource.BTN00033))
                }
                
            },
            _ON_CLICK: function (e) {
                var param = {};
                ecount.confirm("삭제하시겠습니까?", function(e){
                    if(e){
                       ecount.common.api({
                           url : "/ECAPI/SVC/Basic/Sample/DeleteSampleData",
                           data : param,
                           success : function(result){
                               if(result.Status == "200"){
                                   this.sendMessage({callback: this.close.bind(this)});
                               }else{
                                   ecount.alert("false");
                               }
                           }.bind(this)
                       });
                    }
                }.bind(this));
            }

        }
    },

    //사용안함 버튼
    onInitUnitWidgetNotUse: function () {
        return {
            init: function () {
                eccomposite_v1.unit.widget.prototype.init.apply(this, arguments);
            },
            
            render: function (parent) {
                eccomposite_v1.unit.widget.prototype.render.apply(this, arguments);
                this.createLayout(parent);

                //이벤트 바인딩	
                this.createButtonEvent();
            },

            createLayout: function (parent) {
                var ctrl = widget.generator.control();
               if(this.pageOption.EditMode && this.pageOption.EditMode === "02"){
                    parent.addLeft(ctrl.define("widget.button", this.id, '')
                        .label(ecount.resource.LBL01450))
                }
                
            },
            _ON_CLICK : function(){
                var param = {
                    "Request": {
                      "Data": {
                        "CODE": "test",
                        "CODE_NAME": "test",
                        "REMARKS": "test",
                        "USE_YN": "0",
                      },
                      "EditMode": "01"
                    }
                  };
                  
                ecount.common.api({
                    url: "/ECAPI/SVC/Basic/Sample/UpdateSampleUseYn",
                    data: Object.toJSON(param),
                    success: function(result){
                        if(result.Status == "200"){
                            this.sendMessage({callback: this.close.bind(this)});
                        }else{
                            return false;
                        }
                    }.bind(this),
                    error: function(result){
                        console.log(result);
                    }
                });
            }
        }
    },

    //form
    onInitGroupFormInv: function () {
        return {
            isOverriding: true,
            
            getInputFormMaster: function (flag) {
                return this.formInfos["TI001"]
            },
            onInitControl: function(){

            },
            // onLoadComplete : function(){

            // }
        }
    },

    onInitUnitWidgetCode: function(){
        return{
            init: function () {
                eccomposite_v1.unit.widget.prototype.init.apply(this, arguments);
            },
            
            render: function (parent) {
                eccomposite_v1.unit.widget.prototype.render.apply(this, arguments);
                this.createLayout(parent);

            },

            createLayout: function (parent) {
                var ctrl = widget.generator.control();
                parent.add(ctrl
                            .define("widget.input",this.id,this.id,"코드")
                            .dataRules(['required']) 
                            .readOnly(this.pageOption.readOnly)
                            .end())
            },
        }
    },


    onInitUnitWidgetCodeName: function(){
        return{
            init: function () {
                eccomposite_v1.unit.widget.prototype.init.apply(this, arguments);
            },
            
            render: function (parent) {
                eccomposite_v1.unit.widget.prototype.render.apply(this, arguments);
                this.createLayout(parent);

            },

            createLayout: function (parent) {
                var ctrl = widget.generator.control();
                parent.add(ctrl
                            .define("widget.input",this.id,this.id,"코드명")
                            .dataRules(['required']) 
                            .end())
            },
        }
    },
    onInitUnitWidgetRemarks: function(){
        return{
            init: function () {
                eccomposite_v1.unit.widget.prototype.init.apply(this, arguments);
            },
            
            render: function (parent) {
                eccomposite_v1.unit.widget.prototype.render.apply(this, arguments);
                this.createLayout(parent);

            },

            createLayout: function (parent) {
                var ctrl = widget.generator.control();
                parent.add(ctrl
                            .define("widget.input",this.id,this.id,"적요")
                            .end())
                
            },
        }
    },
    consoleTi: function(data){
        console.log("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");
        console.log(data);
        console.log("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");
    }
});