var viewBag2 = window["viewBag" + __EC_PAGE_ID]
viewBag2.InitDatas.viewData = {
    "CODE": "test01",
    "CODE_NAME": "testName",
    "REMARKS": "testRemark",
    "USE_YN": "1",
    "EDIT_MODE": "01"
  }
