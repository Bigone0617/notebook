ecount.page.factory("ecount.page.popup.type2","SAMPLE003M",{
    init: function(){
        this._super.init.apply(this, arguments);
    },

    render: function(){
        this._super.render.apply(this, arguments);
        this.inInitDeafultPageData();

    },

    inInitDeafultPageData: function(){
        this.slipInfo = {
            CODE : "",
            CODE_NAME : "",
            REMARKS : "",
            USE_YN : "",
            EDIT_MODE : ""
        }
       this.slipInfo = _.merge({},this.slipInfo, this.viewBag.InitDatas.viewData);
    },

    onInitHeader: function(header){
        if(this.slipInfo.EDIT_MODE == "01"){
            header.setTitle("Sample Input");
        }else{
            header.setTitle("Sample Update");
        }
        
    },

    onInitContents: function(contents){
        var g = widget.generator,
        form = g.form(),
        control = g.control();

        form.add(control
                .define("widget.input","code","code","코드")
                .dataRules(['required']) 
                .end());
        form.add(control
                .define("widget.input","code_name","code_name","코드명")
                .dataRules(['required']) 
                .end());
        form.add(control
                .define("widget.input","remark","remark","적요")
                .end());

        contents.add(form);
    },

    onInitFooter: function(footer){
        var g  = widget.generator,
        control = g.control(),
        subControl = g.control(),
        toolbar = g.toolbar().setId("footerToolbar");
        
        var label = "사용";
       if(this.slipInfo.USE_YN == "0"){
            label = "사용안함";
       }
        toolbar
            .addLeft(control.define("widget.button","save").label(ecount.resource.BTN00065).end());
        if(this.slipInfo.EDIT_MODE == "02"){
        toolbar
            .addLeft(subControl.define("widget.button","delete").label(ecount.resource.BTN00033).end())
            .addLeft(subControl.define("widget.button","notUse").label(label).end())
        }
        toolbar
            .addLeft(control.define("widget.button","close").label(ecount.resource.BTN00008).end());

            
        footer.add(toolbar);
    },
    onInitControl : function(cid, control){
        if(this.slipInfo.EDIT_MODE == "02"){
            if(cid == "code"){
                control.value(this.slipInfo.CODE)
                        .readOnly();
            }else if(cid == 'code_name'){
                control.value(this.slipInfo.CODE_NAME);
            }else if(cid == 'remark'){
                control.value(this.slipInfo.REMARKS)
            }
        }
    },

    onFooterSave : function(footer){
        var validation = this.contents.validate();
        if(validation.result.length > 0) {
            validation.result[0][0].control.setFocus(0);//setfocus는 cindex이다
            return;
        }
        var param = {
            "Request": {
              "Data": {
                "CODE": this.content.getControl("code").getValue(),
                "CODE_NAME": this.content.getControl("code_name").getValue(),
                "REMARKS": this.content.getControl("remark").getValue(),
                "USE_YN": this.slipInfo.Data.USE_YN,
              },
              "EditMode": this.slipInfo.EDIT_MODE
            }
          };
        ecount.common.api({
            url: "/ECAPI/SVC/Basic/Sample/SaveSampleData",
            data: param,
            success: function(result){
                if(result.Status == "200"){
                    this.sendMessage(this,{callback: this.close.bind(this)});
                }else{
                    return false;
                }
            }.bind(this),
            error: function(result){
                console.log(result);
            }
        });
    },
    ON_KEY_F8 : function(e){
        this.onFooterSave(e);
    },

    onFooterDelete : function(footer){
        
        ecount.confirm("삭제하시겠습니까?", function(e){
            var param = {
                "Request": {
                  "Data": {
                    "CODE": this.contents.getControl("code").getValue()
                  },
                  "EditMode": "01"
                }
              };
            if(e){
                ecount.common.api({
                    url : "/ECAPI/SVC/Basic/Sample/DeleteSampleData",
                    data : Object.toJSON(param),
                    success : function(result){
                        if(result.Status == "200"){
                            this.sendMessage(this,{callback: this.close.bind(this)});
                        }else{
                            ecount.alert("false");
                        }
                    }.bind(this),
                    error: function(result){
                    }
                });
            }
        }.bind(this));
    },
    onFooterNotUse : function(footer){
        var param = {
            "Request": {
              "Data": {
                "CODE": this.content.getControl("code").getValue(),
                "USE_YN": "0",
              },
              "EditMode": this.slipInfo.EDIT_MODE
            }
          };
          
        ecount.common.api({
            url: "/ECAPI/SVC/Basic/Sample/UpdateSampleUseYn",
            data: Object.toJSON(param),
            success: function(result){
                if(result.Status == "200"){
                    this.sendMessage(this,{callback: this.close.bind(this)});
                }else{
                    return false;
                }
            }.bind(this),
            error: function(result){
                console.log(result);
            }
        });
    },
    onFooterClose : function(footer){
        this.close();
    },
})