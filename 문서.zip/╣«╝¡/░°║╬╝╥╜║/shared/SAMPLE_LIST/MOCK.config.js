ecount.env.mock.register({
    MOCKMap: {
        page: {
            "/ECERP/SVC/SAMPLE/SAMPLE002M": {
                mockup: {
                    type: "default",
                    cshtml: "",
                    css: ""
                },
                option: {
                    pageCtrl: "/MOCK/shared/SAMPLE_LIST/SAMPLE002M.js",
                    dataCtrl: "/MOCK/shared/SAMPLE_LIST/SAMPLE002M.datactrl.js"
                },
                postDataDecorator: function (param) {
                    param.Options = {
                      CustomViewData: [
                        {
                          Method:"INPUT",
                          FormData:{
                            FormType: "TI001",
                            FormSeq:1,
                            SetManuallyOption: {
                              ViewType: "I",//ENUM_XFORM_VIEW_TYPE
                            }
                          },
                          DetailData: [
                            {
                              ColCd:"code",
                              ColNm: ecount.resource.LBL00737,
                              ControlType: "widget.input",
                              DataType: "TEXT", //ENUM_DATA_TYPE1
                              IsRequired: true
                            },
                            {
                              ColCd:"code_name",
                              ColNm: ecount.resource.LBL02878,
                              ControlType: "widget.input",
                              DataType: "TEXT", //ENUM_DATA_TYPE1
                              IsRequired: true
                            },
                            {
                              ColCd:"remarks",
                              ColNm: ecount.resource.LBL01418,
                              ControlType: "widget.input",
                              DataType: "TEXT", //ENUM_DATA_TYPE1
                            },
                            {
                                Colcd: "cust",
                                ColNm: ecount.resource.LBL00183,
                                ControlType: "widget.code.cust",
                                DataType: "TEXT"
                            }
                          ]
                        }
                      ],
                      MockUpProgramInfo: {
                        ProgramId: "E040802",
                        NameResource: "LBL35574"
                      },
  
                    };
                    return param;
                }
            },

            "/ECERP/SVC/ESD/ESD007M": {
                mockup: {
                    type: "Default",
                    cshtml: "",
                    css: ""
                },
                option: {
                    pageCtrl: "/MOCK/shared/SAMPLE_LIST/SAMPLE001M.js",
                    dataCtrl: "/MOCK/shared/SAMPLE_LIST/SAMPLE001M.datactrl.js"
                },
                postDataDecorator: function (param) {
                    param.Options = {
                        CustomViewData: [
                            {
                                Method: "LIST",
                                FormData: {
                                    FormType: "TR001",
                                    FormSeq: 1,
                                    SetManuallyOption: {
										ViewType: "R",//ENUM_XFORM_VIEW_TYPE
                                    }
                                },
                                DetailData: [
                                    {
                                        ColCd:"CODE",
                                        ColNm:ecount.resource.LBL00737,
                                        ControlType: "widget.label",
                                        DataType: "TEXT", //ENUM_DATA_TYPE1
                                        FieldSize: 150,
                                        IsRequired: true
                                    },
                                    {
                                        ColCd:"CODE_NAME",
                                        ColNm:ecount.resource.LBL02878,
                                        ControlType: "widget.label",
                                        DataType: "TEXT", //ENUM_DATA_TYPE1
                                        FieldSize: 200,
                                        IsRequired: true
                                    },
                                    {
                                        ColCd:"REMARKS",
                                        ColNm:ecount.resource.LBL01418,
                                        ControlType: "widget.label",
                                        FieldSize: 200,
                                        DataType: "TEXT", //ENUM_DATA_TYPE1
                                    },
                                    {
                                        ColCd:"USE_YN",
                                        ColNm:ecount.resource.LBL35244,
                                        ControlType: "widget.label",
                                        FieldSize: 150,
                                        DataType: "TEXT", //ENUM_DATA_TYPE1
                                    }
                                ]
                            }
                        ],
						SearchFormData: {
							Method:"SEARCH",
							FormData:{
								SetManuallyOption: {
									ViewType: "H"//ENUM_XFORM_VIEW_TYPE
								}
							},
							DetailData: [
								{
									TabCd: "Basic", Title: "기본",
									SubItems: [
										{BitMask:0, BitMaskType:null, controlOption:null,controlType:"widget.input",
										 data:null, displayNmae:null, groupColCd:null, groupId:null,
										 id:"txtTestCode",
										 index:0, isResettableSubTitle:"S",name:"CODE",
										 pairId:null, realId:"txtTestCode", subTitle: ecount.resource.LBL00737, title:"Sample List",
										 usertableCd:null
										},
										{BitMask:0, BitMaskType:null, controlOption:null,controlType:"widget.input",
										 data:null, displayNmae:null, groupColCd:null, groupId:null,
										 id:"txtTestCodeName",
										 index:1, isResettableSubTitle:"S",name:"CODE_NAME",
										 pairId:null, realId:"txtTestCodeName", subTitle: ecount.resource.LBL02878, title:"Sample List",
										 usertableCd:null
										},
										{BitMask:0, BitMaskType:null, controlOption:null,controlType:"widget.input",
										 data:null, displayNmae:null, groupColCd:null, groupId:null,
										 id:"txtRemarks",
										 index:2, isResettableSubTitle:"S",name:"REMARKS",
										 pairId:null, realId:"txtRemarks", subTitle: ecount.resource.LBL01418, title:"Sample List",
										 usertableCd:null
                                        },
										{BitMask:0, BitMaskType:null, controlOption:null,controlType:"widget.radio",
										 data:null, displayNmae:null, groupColCd:null, groupId:null,
										 id:"chkUseYn",
										 index:2, isResettableSubTitle:"S",name:"USE_YN",
										 pairId:null, realId:"chkUseYn", subTitle: ecount.resource.LBL35244, title:"Sample List",
										 usertableCd:null
										}
									]
								},
								{
									TabCd: "all", Title: "전체",
									SubItems: [
										{BitMask:0, BitMaskType:null, controlOption:null,controlType:"widget.input",
										 data:null, displayNmae:null, groupColCd:null, groupId:null,
										 id:"txtTestCode",
										 index:0, isResettableSubTitle:"S",name:"CODE",
										 pairId:null, realId:"txtTestCode", subTitle: ecount.resource.LBL00737, title:"판매조회",
										 usertableCd:null
										},
										{BitMask:0, BitMaskType:null, controlOption:null,controlType:"widget.input",
										 data:null, displayNmae:null, groupColCd:null, groupId:null,
										 id:"txtTestCodeName",
										 index:1, isResettableSubTitle:"S",name:"CODE_NAME",
										 pairId:null, realId:"txtTestCodeName", subTitle: ecount.resource.LBL02878, title:"판매조회",
										 usertableCd:null
										},
										{BitMask:0, BitMaskType:null, controlOption:null,controlType:"widget.input",
										 data:null, displayNmae:null, groupColCd:null, groupId:null,
										 id:"txtRemarks",
										 index:2, isResettableSubTitle:"S",name:"REMARKS",
										 pairId:null, realId:"txtRemarks", subTitle: ecount.resource.LBL01418, title:"판매조회",
										 usertableCd:null
                                        },
										{BitMask:0, BitMaskType:null, controlOption:null,controlType:"widget.radio",
										 data:null, displayNmae:null, groupColCd:null, groupId:null,
										 id:"chkUseYn",
										 index:2, isResettableSubTitle:"S",name:"USE_YN",
										 pairId:null, realId:"chkUseYn", subTitle: ecount.resource.LBL35244, title:"판매조회",
										 usertableCd:null
										}
									]
								},
							]
						}
                    }

                    return param;
                }
            },
            "/ECERP/SVC/ESD/ESD006M": {
                mockup: {
                    type: "Default",
                    cshtml: "",
                    css: ""
                },
                option: {
                    pageCtrl: "/MOCK/shared/SAMPLE_LIST/SAMPLE003M.js",
                    // dataCtrl: "/MOCK/shared/SAMPLE_LIST/SAMPLE003M.datactrl.js"
                },
                postDataDecorator: function (param) {
                    param.Options = {
                        CustomViewData: [
                            {
                                Method: "LIST",
                                FormData: {
                                    FormType: "TR001",
                                    FormSeq: 1,
                                    SetManuallyOption: {
										ViewType: "R",//ENUM_XFORM_VIEW_TYPE
                                    }
                                },
                                DetailData: [
                                    {
                                        ColCd:"CODE",
                                        ColNm:ecount.resource.LBL00737,
                                        ControlType: "widget.label",
                                        DataType: "TEXT", //ENUM_DATA_TYPE1
                                        FieldSize: 150,
                                        IsRequired: true
                                    },
                                    {
                                        ColCd:"CODE_NAME",
                                        ColNm:ecount.resource.LBL02878,
                                        ControlType: "widget.label",
                                        DataType: "TEXT", //ENUM_DATA_TYPE1
                                        FieldSize: 200,
                                        IsRequired: true
                                    },
                                    {
                                        ColCd:"REMARKS",
                                        ColNm:ecount.resource.LBL01418,
                                        ControlType: "widget.label",
                                        FieldSize: 200,
                                        DataType: "TEXT", //ENUM_DATA_TYPE1
                                    },
                                    {
                                        ColCd:"USE_YN",
                                        ColNm:ecount.resource.LBL35244,
                                        ControlType: "widget.label",
                                        FieldSize: 150,
                                        DataType: "TEXT", //ENUM_DATA_TYPE1
                                    }
                                ]
                            }
                        ],
						SearchFormData: {
							Method:"SEARCH",
							FormData:{
								SetManuallyOption: {
									ViewType: "H"//ENUM_XFORM_VIEW_TYPE
								}
							},
							DetailData: [
								{
									TabCd: "Basic", Title: "기본",
									SubItems: [
										{BitMask:0, BitMaskType:null, controlOption:null,controlType:"widget.input",
										 data:null, displayNmae:null, groupColCd:null, groupId:null,
										 id:"txtTestCode",
										 index:0, isResettableSubTitle:"S",name:"CODE",
										 pairId:null, realId:"txtTestCode", subTitle: ecount.resource.LBL00737, title:"Sample List",
										 usertableCd:null
										},
										{BitMask:0, BitMaskType:null, controlOption:null,controlType:"widget.input",
										 data:null, displayNmae:null, groupColCd:null, groupId:null,
										 id:"txtTestCodeName",
										 index:1, isResettableSubTitle:"S",name:"CODE_NAME",
										 pairId:null, realId:"txtTestCodeName", subTitle: ecount.resource.LBL02878, title:"Sample List",
										 usertableCd:null
										},
										{BitMask:0, BitMaskType:null, controlOption:null,controlType:"widget.input",
										 data:null, displayNmae:null, groupColCd:null, groupId:null,
										 id:"txtRemarks",
										 index:2, isResettableSubTitle:"S",name:"REMARKS",
										 pairId:null, realId:"txtRemarks", subTitle: ecount.resource.LBL01418, title:"Sample List",
										 usertableCd:null
                                        },
										{BitMask:0, BitMaskType:null, controlOption:null,controlType:"widget.radio",
										 data:null, displayNmae:null, groupColCd:null, groupId:null,
										 id:"chkUseYn",
										 index:2, isResettableSubTitle:"S",name:"USE_YN",
										 pairId:null, realId:"chkUseYn", subTitle: ecount.resource.LBL35244, title:"Sample List",
										 usertableCd:null
										}
									]
								},
								{
									TabCd: "all", Title: "전체",
									SubItems: [
										{BitMask:0, BitMaskType:null, controlOption:null,controlType:"widget.input",
										 data:null, displayNmae:null, groupColCd:null, groupId:null,
										 id:"txtTestCode",
										 index:0, isResettableSubTitle:"S",name:"CODE",
										 pairId:null, realId:"txtTestCode", subTitle: ecount.resource.LBL00737, title:"판매조회",
										 usertableCd:null
										},
										{BitMask:0, BitMaskType:null, controlOption:null,controlType:"widget.input",
										 data:null, displayNmae:null, groupColCd:null, groupId:null,
										 id:"txtTestCodeName",
										 index:1, isResettableSubTitle:"S",name:"CODE_NAME",
										 pairId:null, realId:"txtTestCodeName", subTitle: ecount.resource.LBL02878, title:"판매조회",
										 usertableCd:null
										},
										{BitMask:0, BitMaskType:null, controlOption:null,controlType:"widget.input",
										 data:null, displayNmae:null, groupColCd:null, groupId:null,
										 id:"txtRemarks",
										 index:2, isResettableSubTitle:"S",name:"REMARKS",
										 pairId:null, realId:"txtRemarks", subTitle: ecount.resource.LBL01418, title:"판매조회",
										 usertableCd:null
                                        },
										{BitMask:0, BitMaskType:null, controlOption:null,controlType:"widget.radio",
										 data:null, displayNmae:null, groupColCd:null, groupId:null,
										 id:"chkUseYn",
										 index:2, isResettableSubTitle:"S",name:"USE_YN",
										 pairId:null, realId:"chkUseYn", subTitle: ecount.resource.LBL35244, title:"판매조회",
										 usertableCd:null
										}
									]
								},
							]
						}
                    }

                    return param;
                }
            },
        },
        api: {
            "/ECAPI/SVC/Basic/Sample/GetListSampleData": {
                host: "test.ecounterp.com",
                status: 200,
                url: "/MOCK/shared/SAMPLE_LIST/GetListSampleData.aspx"
            },
            "/ECAPI/SVC/Basic/Sample/SaveSampleData": {
                host: "test.ecounterp.com",
                status: 200,
                url: "/MOCK/shared/SAMPLE_LIST/SaveSampleData.aspx"
            },
            "/ECAPI/SVC/Basic/Sample/DeleteSampleData": {
                host: "test.ecounterp.com",
                status: 200,
                url: "/MOCK/shared/SAMPLE_LIST/DeleteSampleData.aspx"
            },
            "/ECAPI/SVC/Basic/Sample/UpdateSampleUseYn": {
                host: "test.ecounterp.com",
                status: 200,
                url: "/MOCK/shared/SAMPLE_LIST/UpdateSampleUseYn.aspx"
            }
        }
    }
})