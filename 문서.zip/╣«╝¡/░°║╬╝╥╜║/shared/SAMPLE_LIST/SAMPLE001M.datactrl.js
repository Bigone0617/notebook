var _viewBag = window["viewBag" + __EC_PAGE_ID];
_viewBag.FormInfos.formSearch.formType = "TN001";
_viewBag.FormInfos.TN001 = _viewBag.FormInfos.formSearch;

_viewBag.InitDatas.ViewData = [
    {
        "CODE": "00001",
        "CODE_NAME": "테스트01",
        "REMARKS": "",
        "CUST": "a거래처",
        "USE_YN": "1"
    },
    {
        "CODE": "00002",
        "CODE_NAME": "테스트02",
        "REMARKS": "sample remarks02",
        "CUST": "b거래처",
        "USE_YN": "0"
    },
    {
        "CODE": "00003",
        "CODE_NAME": "테스트03",
        "REMARKS": "sample remarks03",
        "CUST": "c거래처",
        "USE_YN": "1"
    },
    {
        "CODE": "00004",
        "CODE_NAME": "테스트04",
        "REMARKS": "",
        "CUST": "d거래처",
        "USE_YN": "0"
    }
] 

debugger;
