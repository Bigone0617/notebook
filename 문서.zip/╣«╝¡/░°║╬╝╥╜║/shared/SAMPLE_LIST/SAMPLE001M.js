ecount.page.factory("ecount.page.list", "SAMPLE001M", {
    init: function () {
        this._super.init.apply(this, arguments);
        this.initProperties()
    },

    render: function () {
        this._super.render.apply(this, arguments);
    },

    initProperties: function () {
        this.searchParam = {
            CODE: "",
            CODE_NAME: "",
            USE_YN: "",
            REMARKS :""
        }
    },

    onInitHeader: function (header) {
        var g = widget.generator,
            contents = g.contents(),
            toolbar = g.toolbar(),
            ctrl = g.control(),
            tabContents = g.tabContents();

        tabContents
            .onSync()
            .setType("TN001")
            .setTypeMaster("TN001")
            .setOptions({ showFormLayer: false })

        toolbar
            .addLeft(ctrl.define("widget.button", "search").label("Search(F8)").end());

        contents.add(tabContents).add(toolbar);

        header
            .setTitle("Sample List")
            .useQuickSearch(true)
            .notUsedBookmark()
            .add("search", null, false)
            .addContents(contents);
    },

    onInitContents: function (contents) {
        var g = widget.generator,
            grid = g.grid();

        grid
            .setFormData(this.viewBag.FormInfos.TR001)
            .setRowData(this.viewBag.InitDatas.ViewData || [])
            .setFormType("TR001")
            .setRowDataUrl("/SVC/Basic/Sample/GetListSampleData")
            .setRowDataParameter(this.searchParam)
            .setColumnPropertyNormalize("upper")
            .setColumnPropertyColumnName("id")

            //Set fixed Header
            .setKeyColumn(["CODE"])
            .setColumnFixHeader(true)
            .setStyleRowBackgroundColor(this.setRowBackgroundColor.bind(this), 'danger')

            //Checkbox Use
            .setCheckBoxUse(true)
            .setCheckBoxMaxCount(100)

            //Paging
            .setPagingUse(true)
            .setPagingRowCountPerPage(this.PAGE_SIZE, true)
            .setPagingUseDefaultPageIndexChanging(true)

            .setEventShadedColumnId(["CODE"], { isAllRemeberShaded: true })
        
            .setCustomRowCell("CODE", this.setGridDataCode.bind(this))
            .setCustomRowCell("USE_YN", this.setGridDataUseYn.bind(this))

        contents.addGrid("dataGrid", grid);
    },

    onInitControl: function (cid, control) {
        switch (cid) {
            case "chkUseYn":
                control
                    .label(["전체", "사용", "사용안함"])
                    .value(["", "1", "0"])
                    .select("")
                break;
        }
    },

    onInitFooter: function (footer) {
        var g = widget.generator,
            toolbar = g.toolbar(),
            ctrl = g.control();

        toolbar.addLeft(ctrl.define("widget.button", "new").label("신규").end());

        footer.add(toolbar);
    },

    setRowBackgroundColor: function (data) {
        if (data["USE_YN"] == "0") {
            return true
        }
    },

    setGridDataCode: function (value, rowItem) {
        var option = {};
        option.data = value;
        option.controlType = "widget.link";
        option.event = {
            "click": function (e, data) {
                this.openWindow({
                    url: "/ECERP/SVC/SAMPLE/SAMPLE002M",
                    popupType: false,
                    param: {
                        CODE: data.rowItem.CODE,
                        width: 500,
                        height: 250,
                        EditMode: ecenum.editMode.modify
                    }
                })
            }.bind(this)
        };

        return option;
    },

    setGridDataUseYn: function (value, rowItem) {
        var option = {};
        option.data = value == "1" ? "사용" : "사용안함";
        return option;
    },

    onHeaderSearch: function (e) {
        this.searchParam = _.merge({}, this.searchParam, this.header.serialize().result);
        this.searchParam.PARAM = "";
        this.contents.getGrid().grid.clearChecked();

        if (this.dataSearch()) {
            this.header.toggle();
        }
    },

    //Header Quick Search
    onHeaderQuickSearch: function (event) {
        this.searchParam.PARAM = this.header.getQuickSearchControl().getValue();

        var grid = this.contents.getGrid();
        grid.grid.removeShadedColumn();
        grid.getSettings().setPagingCurrentPage(1);
        grid.draw(this.searchParam);
    },

    dataSearch: function () {
        var gridObj = this.contents.getGrid("dataGrid");

        var tabId = this.header.currentTabId;
        var invalid = this.header.validate(tabId);
        if (invalid.result.length > 0) {
            return;
        }

        this.contents.getGrid().grid.removeShadedColumn();

        gridObj.draw(this.searchParam);

        this.header.toggle(true);
    },

    onFooterSave: function (e) {
        this.openWindow({
            url: "/ECERP/SVC/SAMPLE/SAMPLE002M",
            popupType: false,
            param: {
                width: 500,
                height: 250,
                EditMode: ecenum.editMode.new
            }
        });
    },

    onLoadComplete: function (e) {
        if (!e.unfocus) {
            this.header.getQuickSearchControl().setFocus(0);
        }
    },
});