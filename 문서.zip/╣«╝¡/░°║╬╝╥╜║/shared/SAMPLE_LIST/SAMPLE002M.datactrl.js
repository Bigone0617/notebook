var viewBag = window["viewBag" + __EC_PAGE_ID];

// 신규화면
// viewBag.DefaultOption.EditMode = ecenum.editMode.new


//
viewBag.DefaultOption.UIOption = {};

// 수정화면
viewBag.DefaultOption.EditMode = ecenum.editMode.modify
viewBag.InitDatas.ViewData = {
    CODE: "00003",
    CODE_NAME: "테스트03",
    REMARKS: "sample remarks03",
    USE_YN: "Y"
}
