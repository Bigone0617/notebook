/***********************************************************************************
1. Create Date : yyyy.mm.dd
2. Creator     : Hong gil dong
3. Description : sample input
4. Precaution  :
5. History     : 
6. MenuPath    : 
7. Old File    :
9. Etc         :
***********************************************************************************/
ecount.page.factory("ecount.page.common", "SAMPLE002M", {
    init: function (options) {
        this.initDefaultPageData();
        this._super.init.apply(this, arguments);
    },

    //render
    render: function () {
        this._super.render.apply(this, arguments);
    },

    initDefaultPageData: function () {
        this.slipInfo = {
            CODE: "",
            CODE_NAME: "",
            REMARKS: "",
            USE_YN: "Y"
        };
    },

    initProperties: function () {
        this.pageOption.columnMap = {
            widget: {
                code: { id: "code", class: "code", isKey:true },
                code_name: { id: "code_name", class: "codeName" },
                remarks: { id: "remarks", class: "remarks" },
            }
        };

        this.slipInfo = _.merge({}, this.slipInfo, this.viewBag.InitDatas.ViewData || {});

        this.pageInfo = {
            FORM_TYPE_GRID: "TI001",
            inputTitle: "Sample Input", //코드입력
            modifyTitle: "Sample Update", //코드수정
            pageHeader: [
                { 
                    group: "header", id: "header", 
                    child: ["inputTitle"],
                    settingInfo: {
                        bookmark: false
                    }
                }
            ],
            pageContents: [
                {
                    group: "contents", id: "contents",
                    child: [
                        { 
                            group: "form", id: "form", type: "inv"
                        }
                    ]
                }
            ],
            pageFooter: [
                {
                    group: "footer", id: "footer",
                    child: [
                        {
                            group: "toolbar", id: "footerToolbar",
                            child: [
                                "save", "delete",
                                {
                                    id: "useYn",
                                    type: "useYn",
                                    settingInfo: {
                                        useYn: this.slipInfo.USE_YN
                                    }
                                }, "outputClose"]
                        }
                    ]
                }
            ],
            pageFunction: []
        }
    },

    // 캐시 바라보지 않게끔 재정의
    onInitGroupFormInv: function () {
        return {
            isOverriding: true,
            getInputFormMaster: function (flag) {
                return this.formInfos["TI001"]
            },
          
            onInitControl: function (e) {

            },

        }
    },

    onInitUnitWidgetCode: function () {
        return {
            init: function () {
                eccomposite_v1.unit.widget.prototype.init.apply(this, arguments);
            },
            
            render: function (parent) {
                eccomposite_v1.unit.widget.prototype.render.apply(this, arguments);
                this.createLayout(parent);
            },

            onInitControl: function (cid, control) {
                control.value(this.slipInfo.CODE);
            },

            createLayout: function (parent) {
                var ctrl = widget.generator.control();

                parent.add(ctrl.define("widget.input", this.id, '', ecount.resource.LBL00737).dataRules(["required"]).readOnly().end());
            }
        }
    },

    onInitUnitWidgetCodeName: function () {
        return {
            init: function () {
                eccomposite_v1.unit.widget.prototype.init.apply(this, arguments);
            },
            
            render: function (parent) {
                eccomposite_v1.unit.widget.prototype.render.apply(this, arguments);

                this.createLayout(parent);
            },

            onInitControl: function (cid, control) {
                control.value(this.slipInfo.CODE_NAME);
            },

            createLayout: function (parent) {
                var ctrl = widget.generator.control();

                parent.add(ctrl.define("widget.input", this.id, '', ecount.resource.LBL02878).dataRules(["required"]).end());
            }
        }
    },

    onInitUnitWidgetRemarks: function () {
        return {
            init: function () {
                eccomposite_v1.unit.widget.prototype.init.apply(this, arguments);
            },
            
            render: function (parent) {
                eccomposite_v1.unit.widget.prototype.render.apply(this, arguments);
                this.createLayout(parent);
            },

            onInitControl: function (cid, control) {
                control.value(this.slipInfo.REMARKS);
            },

            createLayout: function (parent) {
                var ctrl = widget.generator.control();

                parent.add(ctrl.define("widget.input", this.id, '', ecount.resource.LBL01418).end());
            }
        }
    },

    onInitUnitWidgetSave: function () {
        return {
            init: function () {
                eccomposite_v1.unit.widget.prototype.init.apply(this, arguments);
            },
            
            render: function (parent) {
                eccomposite_v1.unit.widget.prototype.render.apply(this, arguments);
                this.createLayout(parent);

                //단축키 등록
                this.saveShortCutKey("F8");

                //이벤트 바인딩	
                this.createButtonEvent();
            },

            createLayout: function (parent) {
                var ctrl = widget.generator.control();

                parent.addLeft(ctrl.define("widget.button", this.id, '')
                        .label(ecount.resource.BTN00065)
                        .clickOnce())
            },

            _ON_CLICK: function (e) {
                var invalid = this.getLayout("contents").validate();
                if (invalid.result.length > 0) {
                    this.myControl.setAllowClick();
                    invalid.result[0][0].control.setFocus(0);
                    invalid.result[0][0].control.showError();            
                    return false;
                }

                var param = {
                    Request: {
                        Data: {
                            CODE: this.getComposite("code").myControl.getValue(),
                            CODE_NAME: this.getComposite("code_name").myControl.getValue(),
                            REMARKS: this.getComposite("remarks").myControl.getValue(),
                        },
                        EditMode: this.pageOption.EditMode
                    }
                };

                ecount.common.api({
                    url: "/ECAPI/SVC/Basic/Sample/SaveSampleData",
                    param: param,
                    success: function (status) {
                        if (status.Data.Error) {
                            var msg = "";
                            switch (status.Data.Error.Type) {
                                case "duplicate":
                                    msg = "중복된 코드입니다.";
                                    break;
                            }
                            ecount.alert(msg);
                        } else {
                            debugger
                            
                            this.sendMessage({ callback: this.close.bind(this) });
                        }
                    }.bind(this)    
                })
            }
        }
    }

    ,

    onInitUnitWidgetDelete: function () {
        return {
            init: function () {
                eccomposite_v1.unit.widget.prototype.init.apply(this, arguments);
            },
            
            render: function (parent) {
                eccomposite_v1.unit.widget.prototype.render.apply(this, arguments);
                this.createLayout(parent);

                //이벤트 바인딩	
                this.createButtonEvent();
            },

            execCreateComposite: function () {
                if (this.pageOption.EditMode == ecenum.editMode.new) {
                    return false;
                }

                return true;
            },

            createLayout: function (parent) {
                var ctrl = widget.generator.control();

                parent.addLeft(ctrl.define("widget.button", this.id, '')
                        .label(ecount.resource.BTN00033))
            },

            _ON_CLICK: function (e) {
                var param = {
                    Request: {
                        Data: {
                            CODE: this.getComposite("code").myControl.getValue()
                        }
                    },
                    EditMode: ecenum.editMode.delete
                };
                
                ecount.common.api({
                    url: "/SVC/Basic/Sample/DeleteSampleData",
                    param: param,
                    success: function (status) {
                        this.sendMessage({ callback: this.close.bind(this) });
                    }.bind(this)
                });
            }
        }
    },

    onInitUnitWidgetCust: function () {
        return {
            init: function () {
                eccomposite_v1.unit.widget.prototype.init.apply(this, arguments);
            },

            render: function (parent) {
                eccomposite_v1.unit.widget.prototype.render.apply(this, arguments);
                this.createLayout(parent);
            },

            createLayout: function (parent) {
                var ctrl = widget.generator.control();
                parent.add(ctrl.define("widget.code.cust", this.id, '거래처').end())
            }
        }
    },

    onInitUnitWidgetUseYn: function () {
        return {
            init: function () {
                eccomposite_v1.unit.widget.prototype.init.apply(this, arguments);
            },
            
            render: function (parent) {
                eccomposite_v1.unit.widget.prototype.render.apply(this, arguments);
                this.createLayout(parent);

                //이벤트 바인딩	
                this.createButtonEvent();
            },

            execCreateComposite: function () {
                if (this.pageOption.EditMode == ecenum.editMode.new) {
                    return false;
                }

                return true;
            },

            createLayout: function (parent) {
                var ctrl = widget.generator.control();

                parent.addLeft(ctrl.define("widget.button", this.id, '')
                        .label(this.settingInfo.useYn == "Y" ? ecount.resource.LBL01450 : ecount.resource.LBL01448 ))
            },

            _ON_CLICK: function (e) {
                var param = {
                    Request: {
                        Data: {
                            CODE: this.getComposite("code").myControl.getValue(),
                            USE_YN: this.settingInfo.useYn == "Y" ? "0" : "1"
                        }
                    },
                    EditMode: ecenum.editMode.modify
                };
                
                ecount.common.api({
                    url: "/SVC/Basic/Sample/UpdateSampleUseYn",
                    param: param,
                    success: function (status) {
                        this.sendMessage({ callback: this.close.bind(this) });
                    }.bind(this)
                });
            }
        }
    },
});