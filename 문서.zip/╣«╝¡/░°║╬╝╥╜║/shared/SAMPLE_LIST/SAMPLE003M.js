ecount.page.factory("ecount.page.common", "SAMPLE003M", {
    init: function() {
        this._super.init.apply(this, arguments);
    },

    render: function() {
        this._super.render.apply(this, arguments);
    },

    // inInitDeafultPageData: function(){
    //     this.slipInfo = {
    //         CODE : "",
    //         CODE_NAME : "",
    //         REMARKS : "",
    //         USE_YN : "",
    //         EDIT_MODE : ""
    //     }
    //    this.slipInfo = _.merge({},this.slipInfo, this.viewBag.InitDatas.viewData);
    // },
//chkUseYn
    initProperties: function() {
        this.pageInfo = {
            title : "Sample List",
            pageHeader: [
                { 
                    group: "header", id: "header", 
                    settingInfo: {
                        bookmark : false
                    },
                    child:[
                        {
                            unit: "widget", type:"outputTitle"
                        },
                        { 
                            unit: "widget", type: "quickSearch" 
                        },
                        {
                            group: "tabContents", type: "searchForm", id:"searchForm",
                            functions: ["userTab"],
                            settingInfo: {
                                isInitShowSearchTab: false, // 최초 검색 탭 노출
                                isOnSync: true,
                            },
                        },
                        {
                            group: "toolbar", id: "headerToolbar",
                            child: [
                                { unit: "widget", type:"search"},
                               
                            ]
                        }
                    ]
                }
            ],
            pageContents: [
                { 
                    group: "contents", id: "contents",
                    child: [
                       {
                           group: "grid", type: "form", id:"gridForm_TR001",
                           settingInfo: {

                           },
                       }
                    ]
                }
            ],
            pageFooter: [
                { 
                    group: "footer", id: "footer",
                    child: [
                        {
                            group: "toolbar", id: "footerToolbar", 
                            child: [
                                {
                                    unit: "widget", type: "outputExcel",
                                    settingInfo : {
                                        label : "신규"
                                    }
                                }
                            ]
                        }
                    ]
                }
            ],
            pageFunction: [
            ]
        }
    },
    onInitUnitWidgetChkUseYn : function(){
        return{
            onInitControl: function(cid,control){
                var values = ['0', '1', '2'];
                control.label(["전체","사용","사용안함"])
                       .value(values)
                       .select(0);
            }
        }
    }
});